import compose from 'koa-compose';
import koaRouter from 'koa-router';
import userActions from '../transactional/users/userActions';
import statusCodes from '../utils/statuses/statusCodes';
import { errors } from '../utils/errors';
import authActions from '../transactional/users/authActions';
import { ErrorResponse, FailureResponse, SuccessResponse } from '../utils/responses';

const path = require('path');
const {
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
  verifyAccessToken,
} = require('../utils/jwt');


export const createAuthRoutes = () => {
  const router = koaRouter();

  router.post('/login', async (ctx) => {
    const { email, password } = ctx.request.body;
    const response = await authActions.loginUser(email, password);

    // const response = { status: 200, accessToken, refreshToken };
    ctx.status = response.status;
    ctx.body = response;
  });

  router.get('/authDetails', verifyAccessToken, async (ctx) => {
    const response = { status: 200, payload: ctx.req.payload };
    ctx.status = response.status;
    ctx.body = response;
  });

  router.post('/refreshToken', async (ctx) => {
    const { refreshToken } = ctx.request.body;
    if (!refreshToken) {
      const exception = { errorCode: statusCodes.BAD_REQUEST, errorMessage: errors.JWT_REFRESH_TOKEN_MISSING.message };
      const response = new ErrorResponse(exception, [], statusCodes.BAD_REQUEST);
      ctx.status = response.status;
      ctx.body = response;
      return;
    }
    const userId = await verifyRefreshToken(ctx, refreshToken);
    if (!userId) {
      const exception = { errorCode: statusCodes.NOT_AUTHORIZED, errorMessage: errors.JWT_REFRESH_TOKEN_EXPIRED.message };
      const response = new ErrorResponse(exception, [], statusCodes.NOT_AUTHORIZED);
      ctx.status = response.status;
      ctx.body = response;
    }
    const accessTokenNew = await signAccessToken(userId);
    const refreshTokenNew = await signRefreshToken(userId);
    const response = { status: 200, accessToken: accessTokenNew, refreshToken: refreshTokenNew };
    ctx.status = response.status;
    ctx.body = response;
  });
  return router;
};



const storeServiceRouter = createAuthRoutes();
export default compose([
  storeServiceRouter.routes(),
  storeServiceRouter.allowedMethods(),
]);
