import compose from 'koa-compose';
import koaRouter from 'koa-router';
import userActions from '../transactional/users/userActions';
import modifiersActions from '../transactional/modifiers/modifiersActions';

const path = require('path');

export const createModifiersRoutes = () => {
  const router = koaRouter();

  router.get('/', async (ctx) => {
    const response = await modifiersActions.getAllModifiers(ctx.request.query);
    ctx.status = response.status;
    ctx.body = response;
  });

  // router.get('/userGroups', async (ctx) => {
  //   const response = await userActions.getAllUserGroups();
  //   ctx.status = response.status;
  //   ctx.body = response;
  // });

  // router.get('/email/:userEmail', async (ctx) => {
  //   const response = await userActions.getUserByEmail(ctx.params.userEmail);

  //   ctx.status = response.status;
  //   ctx.body = response;
  // });

  // router.put('/:userId', async (ctx) => {
  //   const response = await userActions.updateUser(ctx.state.userId, ctx.params.userId, ctx.request.body);

  //   ctx.status = response.status;
  //   ctx.body = response;
  // });

  router.post('/', async (ctx) => {
    const response = await modifiersActions.createModifiers(ctx.state.userId, ctx.request.body);
    ctx.status = response.status;
    ctx.body = response;
  });

  // router.delete('/:userId', async (ctx) => {
  //   const response = await userActions.deleteUser(ctx.state.userId, ctx.params.userId);

  //   ctx.status = response.status;
  //   ctx.body = response;
  // });


  return router;
};



const storeServiceRouter = createModifiersRoutes();
export default compose([
  storeServiceRouter.routes(),
  storeServiceRouter.allowedMethods(),
]);
