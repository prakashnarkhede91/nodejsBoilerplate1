import database from '../../data/database';
import { valueValidators } from '../../utils/validators';
import { ErrorResponse, FailureResponse, SuccessResponse, getResponse } from '../../utils/responses';
import { errorHandlers, errors } from '../../utils/errors';
import modelActions from '../modelActions';
import { encrypt } from '../../utils/crypto/encrypt';
import { mapModifiersDetails } from './modifiers';
import { queryGenerator } from '../../utils/queries';

const USERS = 'Users';
const USERGROUPS = 'UserGroups';
const MODIFIERS = 'Modifiers';

const modifiersActions = {
    getAllModifiers: async (query) => {
    try {
      const response = await modelActions.getAll(MODIFIERS,query);
      return new SuccessResponse(response);
    } catch (exception) {
      // eslint-disable-next-line
      console.debug(exception);
      return new ErrorResponse(exception);
    }
  },

  getAllUserGroups: async () => {
    try {
      const response = await modelActions.getAll(USERGROUPS);
      const encryptUserGroups = encrypt(JSON.stringify(response));
      // return getResponse(encryptUserGroups);
      return new SuccessResponse(encryptUserGroups);
    } catch (exception) {
      // eslint-disable-next-line
      console.debug(exception);
      return new ErrorResponse(exception);
    }
  },

  getUserByEmail: async (email) => {
    try {
      const user = await database.Users.getOneByEmailOrPhone(email);
      const encryptUser = encrypt(JSON.stringify(user));

      if (!valueValidators.hasValue(user)) {
        return new FailureResponse(errors.USER_NOT_FOUND);
      }

      return new SuccessResponse(encryptUser);
    } catch (exception) {
      // eslint-disable-next-line
      console.debug(exception);
      errorHandlers.throwException('getUserByEmail', errors.DATABASE_ERROR, exception, `Identifier: ${JSON.stringify(email)}`);
      return new ErrorResponse(exception);
    }
  },

  updateUser: async (userId, id, updatedUserDetails) => {
    const transaction = await database.sequelize.transaction();

    try {
      const userFromDb = await modelActions.getOne(USERS, { id }, true);

      const { cellphone, code, extension } = updatedUserDetails; // code
      if (code) {
        const userExists = await modelActions.doesExist(USERS, { code });
        if (userExists.data) {
          return new FailureResponse(errors.USER_UNIQUE_CODE_EXISTS);
        }
      }

      if (cellphone && cellphone !== userFromDb.cellphone) {
        const userExists = await modelActions.getOne(USERS, { cellphone }, true);
        if (userExists && userExists.id !== updatedUserDetails.id) {
          return new FailureResponse(errors.USER_CELLPHONE_EXISTS);
        }
      }

      if (extension) {
        const userExists = await modelActions.doesExist(USERS, { extension });
        if (userExists.data) {
          return new FailureResponse(errors.USER_EXTENSION_EXISTS);
        }
      }

      const response = await modelActions.update(USERS, id, updatedUserDetails, transaction);
      const encryptUser = encrypt(JSON.stringify(response));

      await transaction.commit();

      return new SuccessResponse(encryptUser);
    } catch (exception) {
      await transaction.rollback();
      // eslint-disable-next-line
      console.debug(exception);
      return new ErrorResponse(exception);
    }
  },

  createModifiers: async (userId, newModifiersDetails) => {
    const transaction = await database.sequelize.transaction();
    const user = { id: 1, customerUuid: '15e419e7-c369-46d5-aa10-fd897c2592a8' };
    try {
      
      const orderSeq = await modelActions.getOrder(MODIFIERS);
      console.log('🚀 ^~^ - createModifiers: - orderSeq', orderSeq)
      const validatedInput = mapModifiersDetails(user, newModifiersDetails,orderSeq);
      
      // check if modifierCode exists
      const doesExist = await modelActions.doesExist(MODIFIERS, { modifierCode: validatedInput.modifierCode }, true);
      if (doesExist) {
        return new FailureResponse(errors.MODIFIERS_CODE_EXISTS);
      }
      const response = await modelActions.create(MODIFIERS, userId, validatedInput, transaction);
      // const encryptUser = encrypt(JSON.stringify(response));

      await transaction.commit();

      return new SuccessResponse(response);
    } catch (exception) {
      console.log("exception===",exception);
      await transaction.rollback();
      // eslint-disable-next-line
      console.debug(exception);
      return new ErrorResponse(exception);
    }
  },

  getOneUserById: async (id) => {
    try {
      const response = await modelActions.getOne(USERS, { id }, false);

      return getResponse(response);
    } catch (exception) {
      // eslint-disable-next-line
      console.debug(exception);
      return new ErrorResponse(exception);
    }
  },

  deleteUser: async (userId, identifier) => {
    const transaction = await database.sequelize.transaction();

    try {
      const response = await modelActions.update(USERS, identifier, { isDeleted: true, deletedAt: new Date() }, transaction);
      const encryptUser = encrypt(JSON.stringify(response));

      await transaction.commit();
      return new SuccessResponse(encryptUser);
    } catch (exception) {
      await transaction.rollback();
      // eslint-disable-next-line
      console.debug(exception);
      return new ErrorResponse(exception);
    }
  },

};

export default modifiersActions;
