import { valueValidators } from '../../utils/validators';
import { errors } from '../../utils/errors';
// import { convertQuantityToSpecificUnitType } from '../../conversions';
// import { arithmetic } from '../../utils/operations';
// import { parseNumber, roundWithPrecision } from '../../utils/misc/numbers';
import enums from '../../utils/enums';

// Output incorporates quantity rounding - intended for client response
class Modifiers {
  constructor(stockItemFromDb) {
    valueValidators.mustHaveValue(stockItemFromDb, errors.INVALID_REQUEST, 'stockItemFromDb');

    this.modifierCode = valueValidators.mustHaveValue(stockItemFromDb.modifierCode, errors.STOCKITEM_PROPERTIES_ERROR.STOCKITEM_STOCKCODE_INVALID);
    // this.description = valueValidators.mustHaveValue(stockItemFromDb.description, errors.STOCKITEM_PROPERTIES_ERROR.STOCKITEM_DESCRIPTION_INVALID);
    // this.quantityAvailable = valueValidators.mustHaveValue(arithmetic.formatTo2DecimalPlaces(stockItemFromDb.quantityAvailable), errors.STOCKITEM_PROPERTIES_ERROR.STOCKITEM_QUANTITYAVAILABLE_INVALID);
    // this.wastePercentage = valueValidators.hasValue(stockItemFromDb.wastePercentage) ? stockItemFromDb.wastePercentage : 0;
    // this.manufactured = valueValidators.mustHaveValue(stockItemFromDb.manufactured, errors.STOCKITEM_PROPERTIES_ERROR.STOCKITEM_MANUFACTURED_INVALID);
    // this.batchSize = valueValidators.hasValue(stockItemFromDb.batchSize) ? stockItemFromDb.batchSize : null;
    // this.controllable = valueValidators.mustHaveValue(stockItemFromDb.controllable, errors.STOCKITEM_PROPERTIES_ERROR.STOCKITEM_CONTROLLABLE_INVALID);
    // this.isEnabled = valueValidators.mustHaveValue(stockItemFromDb.isEnabled, errors.STOCKITEM_PROPERTIES_ERROR.STOCKITEM_ISENABLED_INVALID);
    // this.stockCategoryId = valueValidators.mustHaveValue(stockItemFromDb.stockCategoryId, errors.STOCKITEM_PROPERTIES_ERROR.STOCKITEM_CATEGORY_INVALID);
    // this.unitTypeId = valueValidators.mustHaveValue(stockItemFromDb.unitTypeId, errors.STOCKITEM_PROPERTIES_ERROR.STOCKITEM_UNITTYPE_INVALID);
    // this.preferredUnitTypeId = stockItemFromDb.preferredUnitTypeId;
    // this.vatExempt = valueValidators.mustHaveValue(stockItemFromDb.vatExempt, errors.STOCKITEM_PROPERTIES_ERROR.STOCKITEM_VATEXEMPT_INVALID);
    // this.dateOfCapture = stockItemFromDb.dateOfCapture;
    // this.showThresholdOnPosApp = valueValidators.hasValue(stockItemFromDb.showThresholdOnPosApp) ? stockItemFromDb.showThresholdOnPosApp : 0;
    // this.threshold = valueValidators.hasValue(stockItemFromDb.threshold) ? Number(stockItemFromDb.threshold) : 0;
    // this.isReportItem = valueValidators.hasValue(stockItemFromDb.isReportItem) ? stockItemFromDb.isReportItem : 0;
    // this.recipeId = valueValidators.hasValue(stockItemFromDb.Recipes) && stockItemFromDb.Recipes.length > 0 ? stockItemFromDb.Recipes[0].id : null;
    // this.nonDeductable = valueValidators.hasValue(stockItemFromDb.nonDeductable) ? stockItemFromDb.nonDeductable : false;
  }
}

const mapModifiersDetails = (user, modifiersDetails,orderSeq) => {
  valueValidators.mustHaveValue(modifiersDetails, errors.INVALID_REQUEST, 'modifiersDetails');
  return {
    modifierCode: valueValidators.mustHaveValue(modifiersDetails.modifierCode, errors.MODIFIER_PROPERTIES_ERROR.MODIFIER_MODIFIERCODE_INVALID, 'modifierCode'),
    stockCode: valueValidators.mustHaveValue(modifiersDetails.stockCode, errors.MODIFIER_PROPERTIES_ERROR.MODIFIER_STOCKCODE_INVALID, 'stockCode'),
    name: valueValidators.mustHaveValue(modifiersDetails.name, errors.MODIFIER_PROPERTIES_ERROR.MODIFIER_NAME_INVALID, 'name'),
    description: modifiersDetails.description && valueValidators.hasValue(modifiersDetails.description) ? modifiersDetails.description : null,
    amount: valueValidators.mustHaveValue(modifiersDetails.amount, errors.MODIFIER_PROPERTIES_ERROR.MODIFIER_AMOUNT_INVALID, 'amount'),
    extraAmount: valueValidators.mustHaveValue(modifiersDetails.extraAmount, errors.MODIFIER_PROPERTIES_ERROR.MODIFIER_EXTRAAMOUNT_INVALID, 'extraAmount'),
    isRepeatable: valueValidators.hasValue(modifiersDetails.isRepeatable) ? modifiersDetails.isRepeatable : false,
    isUnlimited: valueValidators.hasValue(modifiersDetails.isUnlimited) ? modifiersDetails.isUnlimited : false,
    isLimited: valueValidators.hasValue(modifiersDetails.isLimited) ? modifiersDetails.isLimited : false,
    maxLimitValue: valueValidators.hasValue(modifiersDetails.maxLimitValue) ? modifiersDetails.maxLimitValue : 0,
    isActive: valueValidators.hasValue(modifiersDetails.isActive) ? modifiersDetails.isActive : true,
    order: orderSeq,
    createdBy: user.id,
    updatedBy: user.id,
    customerUuid: user.customerUuid,
  };
};




export { Modifiers, mapModifiersDetails };
