import database from '../../data/database';
import { encrypt } from '../../utils/crypto/encrypt';
import { errors } from '../../utils/errors';
import { ErrorResponse, FailureResponse, SuccessResponse } from '../../utils/responses';
import statusCodes from '../../utils/statuses/statusCodes';
import { valueValidators } from '../../utils/validators';
import Authentication from './authentication';

const {
  signAccessToken,
  signRefreshToken,
} = require('../../utils/jwt');

const SESSIONS = 'Sessions';

const userAuth = {

  authenticateByCode: async (code, rpadmin = false) => {
    try {
      valueValidators.mustHaveValue(code, errors.INVALID_REQUEST, 'code');

      const userFromDb = await database.Users.getOneByCode(code);

      if (!valueValidators.hasValue(userFromDb)) return new FailureResponse(errors.USER_NOT_FOUND, statusCodes.BAD_REQUEST);

      const auth = new Authentication(userFromDb, '', false);
      if (auth.authenticated) {
        const responceData = encrypt(JSON.stringify(auth));
        return new SuccessResponse(responceData);
      }
      return new FailureResponse(errors.USER_AUTH_ERROR, statusCodes.NOT_AUTHORIZED);
    } catch (exception) {
      // eslint-disable-next-line
      console.debug(exception);
      return new ErrorResponse(exception);
    }
  },
  loginUser: async (email, password) => {
    try {
      valueValidators.mustHaveValue(email, errors.INVALID_REQUEST, 'email');
      valueValidators.mustHaveValue(password, errors.INVALID_REQUEST, 'password');

      const userFromDb = await database.Users.getOneByEmail(email, true);

      if (!valueValidators.hasValue(userFromDb)) return new FailureResponse(errors.USER_NOT_FOUND, statusCodes.BAD_REQUEST);

      const auth = new Authentication(userFromDb, password);
      if (auth.authenticated) {
        const accessToken = await signAccessToken(auth.id);
        const refreshToken = await signRefreshToken(auth.id);
        auth.accessToken = accessToken;
        auth.refreshToken = refreshToken;
        // if (rpadmin) await storeVacationCheck(userFromDb.id);
        return new SuccessResponse(auth);
      }

      return new FailureResponse(errors.USER_AUTH_ERROR, statusCodes.NOT_AUTHORIZED);
    } catch (exception) {
      // eslint-disable-next-line
      console.debug(exception);
      return new ErrorResponse(exception);
    }
  },


};

export default userAuth;
