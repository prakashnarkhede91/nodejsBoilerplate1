import database from '../../data/database';
import { valueValidators } from '../../utils/validators';
import { ErrorResponse, FailureResponse, SuccessResponse, getResponse } from '../../utils/responses';
import { errorHandlers, errors } from '../../utils/errors';
import modelActions from '../modelActions';
import { encrypt } from '../../utils/crypto/encrypt';



const USERS = 'Users';
const USERGROUPS = 'UserGroups';

const userActions = {
  getAllUsers: async (query) => {
    try {
      const response = await database[USERS].getAllByPaginated({ isDeleted: false }, query);
      const encryptUser = encrypt(JSON.stringify(response));

      return new SuccessResponse(encryptUser);
    } catch (exception) {
      // eslint-disable-next-line
          console.debug(exception);
      return new ErrorResponse(exception);
    }
  },

  getAllUserGroups: async () => {
    try {
      const response = await modelActions.getAll(USERGROUPS);
      const encryptUserGroups = encrypt(JSON.stringify(response));
      // return getResponse(encryptUserGroups);
      return new SuccessResponse(encryptUserGroups);
    } catch (exception) {
      // eslint-disable-next-line
      console.debug(exception);
      return new ErrorResponse(exception);
    }
  },

  getUserByEmail: async (email) => {
    try {
      const user = await database.Users.getOneByEmailOrPhone(email);
      const encryptUser = encrypt(JSON.stringify(user));

      if (!valueValidators.hasValue(user)) {
        return new FailureResponse(errors.USER_NOT_FOUND);
      }

      return new SuccessResponse(encryptUser);
    } catch (exception) {
      // eslint-disable-next-line
      console.debug(exception);
      errorHandlers.throwException('getUserByEmail', errors.DATABASE_ERROR, exception, `Identifier: ${JSON.stringify(email)}`);
      return new ErrorResponse(exception);
    }
  },

  updateUser: async (userId, id, updatedUserDetails) => {
    const transaction = await database.sequelize.transaction();

    try {
      const userFromDb = await modelActions.getOne(USERS, { id }, true);

      const { cellphone, code, extension } = updatedUserDetails; // code
      if (code) {
        const userExists = await modelActions.doesExist(USERS, { code });
        if (userExists.data) {
          return new FailureResponse(errors.USER_UNIQUE_CODE_EXISTS);
        }
      }

      if (cellphone && cellphone !== userFromDb.cellphone) {
        const userExists = await modelActions.getOne(USERS, { cellphone }, true);
        if (userExists && userExists.id !== updatedUserDetails.id) {
          return new FailureResponse(errors.USER_CELLPHONE_EXISTS);
        }
      }

      if (extension) {
        const userExists = await modelActions.doesExist(USERS, { extension });
        if (userExists.data) {
          return new FailureResponse(errors.USER_EXTENSION_EXISTS);
        }
      }

      const response = await modelActions.update(USERS, id, updatedUserDetails, transaction);
      const encryptUser = encrypt(JSON.stringify(response));

      await transaction.commit();

      return new SuccessResponse(encryptUser);
    } catch (exception) {
      await transaction.rollback();
      // eslint-disable-next-line
      console.debug(exception);
      return new ErrorResponse(exception);
    }
  },

  createUser: async (userId, newUserDetails) => {
    const transaction = await database.sequelize.transaction();

    try {
      const { cellphone, email, code } = newUserDetails;

      // check if user exists
      const userUniqeCodeExists = await modelActions.doesExistUniqueCode(USERS, { cellphone, email, code });
      if (userUniqeCodeExists.data) {
        return new FailureResponse(errors.USER_UNIQUE_CODE_EXISTS);
      }

      const userExists = await modelActions.doesExist(USERS, { cellphone, email, code });
      if (userExists.data) {
        return new FailureResponse(errors.USER_ALREADY_EXISTS);
      }

      const response = await modelActions.create(USERS, userId, newUserDetails, transaction);
      const encryptUser = encrypt(JSON.stringify(response));

      await transaction.commit();

      return new SuccessResponse(encryptUser);
    } catch (exception) {
      await transaction.rollback();
      // eslint-disable-next-line
      console.debug(exception);
      return new ErrorResponse(exception);
    }
  },

  getOneUserById: async (id) => {
    try {
      const response = await modelActions.getOne(USERS, { id }, false);

      return getResponse(response);
    } catch (exception) {
      // eslint-disable-next-line
      console.debug(exception);
      return new ErrorResponse(exception);
    }
  },

  deleteUser: async (userId, identifier) => {
    const transaction = await database.sequelize.transaction();

    try {
      const response = await modelActions.update(USERS, identifier, { isDeleted: true, deletedAt: new Date() }, transaction);
      const encryptUser = encrypt(JSON.stringify(response));

      await transaction.commit();
      return new SuccessResponse(encryptUser);
    } catch (exception) {
      await transaction.rollback();
      // eslint-disable-next-line
      console.debug(exception);
      return new ErrorResponse(exception);
    }
  },

};

export default userActions;
