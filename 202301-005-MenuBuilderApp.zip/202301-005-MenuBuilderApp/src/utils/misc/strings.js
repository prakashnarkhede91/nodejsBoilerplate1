export const isUpperFirst = (input) => {
  return input.charAt(0) === input.toUpperCase().charAt(0);
};