const queryGenerator = {
  orderNumberQuery: table => (`(SELECT count FROM (SELECT count(*) AS count FROM ${table}) AS o ) + 1`),
};

export { queryGenerator };