const errors = {
  ARITHMETIC_OPERATION_ERROR: {
    code: 'EART500',
    message: 'An arithmetic operation failed.',
  },
  BAD_REQUEST: {
    code: 'E400',
    message: 'Validation against the request received was found to be invalid.',
  },
  // #region APP
  APP_PROPERTIES_ERROR: {
    code: 'EAPP400',
    message: 'An app property is invalid.',
    APP_ID_INVALID: {
      code: 'EAPPIDX400',
      message: 'App ID is invalid.',
    },
    APP_DEVICEID_INVALID: {
      code: 'EAPPDVC400',
      message: 'App device id is invalid.',
    },
    APP_TYPE_INVALID: {
      code: 'EAPPTYP400',
      message: 'App type is invalid.',
    },
    APP_STOREID_INVALID: {
      code: 'EAPPSTR400',
      message: 'App store ID is invalid.',
    },
    APP_VERSION_INVALID: {
      code: 'EAPPVRS400',
      message: 'App version is invalid.',
    },
  },
  APP_VERSION_SEMVER_INVALID: {
    code: 'EAPPIDX400',
    message: 'App version must be semver.',
  },
  APP_TYPE_NOT_FOUND: {
    code: 'EAPPTYP404',
    message: 'App type not found.',
  },
  // #region ATTENDANCE
  ATTENDANCE_PROPERTIES_ERROR: {
    code: 'ESATT400',
    message: 'An attendance property is invalid.',
    ATTENDANCE_ID_INVALID: {
      code: 'EATTIDX400',
      message: 'Attendance id is invalid.',
    },
    ATTENDANCE_CHECKED_IN_AT_INVALID: {
      code: 'EATTTIN400',
      message: 'Attendance checked in at is invalid.',
    },
    ATTENDANCE_TIME_OUT_INVALID: {
      code: 'EATTTOT400',
      message: 'Attendance checked out at is invalid.',
    },
    ATTENDANCE_DATE_INVALID: {
      code: 'EATTDTE400',
      message: 'Attendance date is invalid.',
    },
    ATTENDANCE_SUPERVISOR_INVALID: {
      code: 'EATTSPR400',
      message: 'Attendance supervisor is invalid.',
    },
    ATTENDANCE_USER_INVALID: {
      code: 'EATTUSR400',
      message: 'Attendance user is invalid.',
    },
  },
  ATTENDANCE_NOT_FOUND: {
    code: 'EATT404',
    message: 'Attendance not found.',
  },
  ATTENDANCE_EXISTS: {
    code: 'EATTUSR403',
    message: 'An attendace for this user already exists.',
  },
  ATTENDANCE_ALREADY_CHECKED_OUT: {
    code: 'EATTACO400',
    message: 'User already checked out',
  },
  ATTENDANCE_ALREADY_CHECKED_IN: {
    code: 'EATTACI400',
    message: 'User already checked in.',
  },
  ATTENDANCE_DATE_INVALID: {
    code: 'EATTACI401',
    message: 'Check In can only be done for today. Kindly close and reopen the app.',
  },
  // #region BATCHES
  BATCH_CREATE_ERROR: {
    code: 'EBTC500',
    message: 'Failed to create batch.',
  },
  BATCH_NOT_FOUND: {
    code: 'EBTC404',
    message: 'Batch not found.',
  },
  BATCH_NOT_FOUND_FOR_STOCK_ITEM: {
    code: 'EBTCSTK404',
    message: 'No batches found for stock item:',
  },
  BATCH_HISTORY_NOT_FOUND_FOR_STOCK_ITEM: {
    code: 'EBHTCSTK404',
    message: 'No batches ever recorded for stock item:',
  },
  BATCH_DEPLETED_NOT_FOUND_FOR_STOCK_ITEM: {
    code: 'EBTCDPL404',
    message: 'No depleted batches found for stock item.',
  },
  BATCH_QUANTITY_UPDATE_ERROR: {
    code: 'EBTCQTY500',
    message: 'Update to Batch current quantity failed.',
  },
  BATCH_STATE_CHANGE_ERROR: {
    code: 'EBTCSTT500',
    message: 'Update to Batch batch state failed.',
  },
  BATCH_STATE_QUERY_ERROR: {
    code: 'EBTCSTT404',
    message: 'Batch by state not found.',
  },
  BATCHES_PROPERTIES_ERROR: {
    code: 'EBTCP400',
    message: 'A batch property is invalid.',
    BATCH_ID_INVALID: {
      code: 'EBTCPID400',
      message: 'Batch id is invalid.',
    },
    BATCH_SOURCEID_INVALID: {
      code: 'EBTCPSID400',
      message: 'Batch sourceId is invalid.',
    },
    BATCH_SOURCETYPE_INVALID: {
      code: 'EBTCPSRT400',
      message: 'Batch source type is invalid.',
    },
    BATCH_STOCKITEMSTOCKCODE_INVALID: {
      code: 'EBTCPID400',
      message: 'Batch stock item stock code is invalid.',
    },
    BATCH_INCOMINGQUANTITY_INVALID: {
      code: 'EBTCPIQT400',
      message: 'Batch incoming quantity is invalid.',
    },
    BATCH_QUANTITY_ON_HAND_INVALID: {
      code: 'EBTCPQOH400',
      message: 'Batch quantity on hand is invalid.',
    },
    BATCH_ORIGINAL_QUANTITY_INVALID: {
      code: 'EBTCPOQT400',
      message: 'Batch original quantity is invalid.',
    },
    BATCH_ORIGINAL_QUANTITY_LESS_WASTE_INVALID: {
      code: 'EBTCPOQW400',
      message: 'Batch original quantity less waste is invalid.',
    },
    BATCH_UNITTYPEID_INVALID: {
      code: 'EBTCUTI400',
      message: 'Batch unit type id is invalid.',
    },
    BATCH_UNIT_TYPE_ID_INCOMPATIBLE_WITH_STOCK_ITEM_BASE_UNIT_TYPE: {
      code: 'EBTCSUT406',
      message: 'The unit type received is not compatible with the stock item base unit type.',
    },
    BATCH_WASTEPERCENTAGE_INVALID: {
      code: 'EBTCPWSP400',
      message: 'Batch waste percentage is invalid.',
    },
    BATCH_PRICE_INVALID: {
      code: 'EBTCPPRC400',
      message: 'Batch price is invalid.',
    },
    BATCH_UNITCOST_INVALID: {
      code: 'EBTCPUNC400',
      message: 'Batch unit cost is invalid.',
    },
    BATCH_UNITPRICE_INVALID: {
      code: 'EBTCPUNP400',
      message: 'Batch unit price is invalid.',
    },
    BATCH_STATE_INVALID: {
      code: 'EBTCPSTT400',
      message: 'Batch state is invalid.',
    },
  },
  AVERAGE_COST_ERROR: {
    code: 'EAVGCOST406',
    message: 'Based on the information captured. The unit cost of the stock item(s)  will be significantly higher or lower than the expected unit price. ',
  },
  // #endregion
  // #region BATCH DEDUCTIONS
  BATCH_DEDUCTION_ERROR: {
    code: 'EBTCDDC500',
    message: 'An error occurred while processing a deduction against one or multiple batches.',
    BATCH_COUNTER_LOST: {
      code: 'EBTCDDCNT406',
      message: 'Batch counter has been lost - cannot extract update directives without the batch counter.',
    },
    CONTRIBUTION_INVALID: {
      code: 'EBTCDDCCNT406',
      message: 'Batch contribution mapping is invalid.',
    },
    CURRENT_BATCH_INVALID: {
      code: 'EBTCDDCBTC406',
      message: 'Current batch received to process contribution to deduction is invalid.',
    },
    DEDUCTION_CALC_VALIDATION_FAILED: {
      code: 'EBTCDDCCLC500',
      message: 'The amount deducted and the amount to deduct did not match up - some sort of calculation error occurred.',
    },
    DIRECTIVE_TYPE_NOT_RECOGNIZED: {
      code: 'EBTCTYP404',
      message: 'Batch directive type not recognized.',
    },
    DIRECTIVE_TYPE_NOT_PERMITTED: {
      code: 'EBTCTYP401',
      message: 'Batch directives of this type are currently not permitted to transact.',
    },
    DIRECTIVE_INVALID: {
      code: 'EBTCDDCDRC406',
      message: 'Update directive for batch is invalid.',
    },
    INDIVIDUAL_BATCH_CONTRIBUTION_FAILED: {
      code: 'EBTCDDCBTC500',
      message: 'An error occurred whlie processing the contribution of an individual batch for a deduction.',
    },
    DEDUCTION_DETAILS_INVALID: {
      code: 'EBTCDDCDDD406',
      message: 'Deduction details received for batch deduction is invalid.',
    },
    QUANTITY_TO_DEDUCT: {
      code: 'EBTCDDCQTY406',
      message: 'Quantity to deduct for batch deduction is not valid - must be a number greater than 0.',
    },
    UNIT_TYPE_INVALID: {
      code: 'EBTCDDCUTP406',
      message: 'Unit type related to batch deduction is invalid.',
    },
    NO_ACTIVE_OR_WAITING_BATCHES_FOUND_FOR_STOCK_ITEM: {
      code: 'EBTCDDC404',
      message: 'No ACTIVE or WAITING batches were found for the stock item. Deduction cannot be completed.',
    },
    NOT_ENOUGH_ACTIVE_OR_WAITING_BATCHES_FOUND_FOR_STOCK_ITEM: {
      code: 'EBTCDDC404',
      message: 'Not enough ACTIVE or WAITING batches were found for the stock item. Deduction cannot be completed.',
    },
    SAFETY_THRESHOLD_EXCEEDED: {
      code: 'EBTCDDCSFT500',
      message:
        `Failed to deduct quantity <<QUANTITY_DEDCUTED>> (<<UNIT_TYPE>>) for stockItem: <<STOCK_ITEM_CODE>> (<<STOCK_ITEM_DESC>>).
        Please verify that the value you entered for this item is correct.`,
    },
    UPDATED_QUANTITY_INVALID: {
      code: 'EBTCUQT500',
      message: 'The quantity received to update to the batch is invalid.',
    },
    MUTATION_QUANTITY_INVALID: {
      code: 'EBTCMQT500',
      message: 'The quantity received that was mutated on the batch is invalid.',
    },
    DIRECTIVE_TYPE_INVALID: {
      code: 'EBTCDRT500',
      message: 'The type of the directive received is invalid.',
    },
    BATCH_STATE_INDICATOR_INVALID: {
      code: 'EBTCBSI500',
      message: 'The indicator for batch state change is invalid.',
    },
  },
  // #region BATCH DEDUCTIONS
  BATCH_ADDITION_ERROR: {
    code: 'EBTCADD500',
    message: 'An error occurred while processing an addition against one or multiple batches.',
    BATCH_COUNTER_LOST: {
      code: 'EBTCADDNT406',
      message: 'Batch counter has been lost - cannot extract update directives without the batch counter.',
    },
    CONTRIBUTION_INVALID: {
      code: 'EBTCADDCNT406',
      message: 'Batch contribution mapping is invalid.',
    },
    CURRENT_BATCH_INVALID: {
      code: 'EBTCADDBTC406',
      message: 'Current batch received to process contribution to addition is invalid.',
    },
    ADDITION_CALC_VALIDATION_FAILED: {
      code: 'EBTCADDCLC500',
      message: 'The amount added and the amount to add did not match up - a calculation error occurred.',
    },
    DIRECTIVE_INVALID: {
      code: 'EBTCADDDRC406',
      message: 'Update directive for batch is invalid.',
    },
    INDIVIDUAL_BATCH_CONTRIBUTION_FAILED: {
      code: 'EBTCADDBTC500',
      message: 'An error occurred whlie processing the contribution of an individual batch for an addition.',
    },
    ADDITION_DETAILS_INVALID: {
      code: 'EBTCADDDDD406',
      message: 'Addition details received for batch addition is invalid.',
    },
    QUANTITY_TO_ADD: {
      code: 'EBTCADDQTY406',
      message: 'Quantity to add for batch addition is not valid - must be a number greater than 0.',
    },
    UNIT_TYPE_INVALID: {
      code: 'EBTCADDUTP406',
      message: 'Unit type related to batch addition is invalid.',
    },
    NO_ACTIVE_OR_WAITING_BATCHES_FOUND_FOR_STOCK_ITEM: {
      code: 'EBTCADD404',
      message: 'No ACTIVE or WAITING batches were found for the stock item. Addition cannot be completed.',
    },
    NOT_ENOUGH_ACTIVE_OR_WAITING_BATCHES_FOUND_FOR_STOCK_ITEM: {
      code: 'EBTCADD404',
      message: 'Not enough ACTIVE or WAITING batches were found for the stock item. Addition cannot be completed.',
    },
    SAFETY_THRESHOLD_EXCEEDED: {
      code: 'EBTCADDSFT500',
      message:
        `Failed to add quantity <<QUANTITY_ADDED>> (<<UNIT_TYPE>>) for stockItem: <<STOCK_ITEM_CODE>> (<<STOCK_ITEM_DESC>>).
         Please verify that the value you entered for this item is correct.`,
    },
  },
  // #endregion
  // #region BATCH STATES
  BATCHSTATE_NOT_FOUND: {
    code: 'EBTS404',
    message: 'Batch state was not found.',
  },
  BATCHSTATE_PROPERTIES_ERROR: {
    code: 'EBTSP406',
    message: 'A batch state property is invalid.',
    BATCHSTATE_ID_INVALID: {
      code: 'EBTSPID406',
      message: 'Batch state id property is invalid.',
    },
  },
  // #endregion
  // #region CATEGORIES
  CATEGORY_PROPERTIES_ERROR: {
    code: 'ECTG400',
    message: 'A stock category property is invalid.',
    CATEGORY_ID_INVALID: {
      code: 'EUSRID406',
      message: 'Stock category id is invalid.',
    },
    CATEGORY_NAME_INVALID: {
      code: 'EUSRNM406',
      message: 'Stock category name is invalid.',
    },
  },
  // #endregion
  // #region CATEGORIES
  BATCH_UPDATE_FAILED: {
    code: 'EBTCUPT500',
    message: 'Failed to update one ore more batches.',
  },
  BATCH_UPDATE_FAILED_ON_STOCK_RETURN: {
    code: 'EBTUPSR500',
    message: 'Stock Return Failed. You have either tried to return more than what was delivered, or there is insufficient stock available to return.',
  },
  // #endregion
  // #region CUSTOMER
  CUSTOMER_NOT_FOUND: {
    code: 'ECST404',
    message: 'Customer not found.',
  },
  // #endregion
  DATABASE_ACTION_NOT_APPLIED: {
    code: 'EDBA406',
    message: 'The database action was not applied. Possible reasons include trying to update a record which has been deleted.',
  },
  DATABASE_ERROR: {
    code: 'EDB500',
    message: 'A database action failed to execute.',
  },
  INVALID_PERMISSIONS: {
    code: 'EPRM401',
    message: 'User does not have permissions to perform this action.',
  },
  INVALID_REQUEST: {
    code: 'ERQS400',
    message: 'The request received is not valid to complete the action.',
  },
  NOT_IMPLEMENTED: {
    code: 'ENTIMP',
    message: 'Funcitonality has not yet been implemented for this action.',
  },
  // #region CUSTOMER
  INSTRUCTION_NOT_FOUND: {
    code: 'EINS404',
    message: 'Instruction not found.',
  },
  // #region RECIPES
  RECIPES_PROPERTIES_ERROR: {
    code: 'ERCP400',
    message: 'A recipe property is invalid.',
    RECIPE_ID_INVALID: {
      code: 'ERCPID400',
      message: 'Recipe id is invalid.',
    },
    RECIPE_NAME_INVALID: {
      code: 'ERCPNAM400',
      message: 'Recipe name is invalid.',
    },
    RECIPE_RECIPECODE_INVALID: {
      code: 'ERCPRCD400',
      message: 'Recipe recipeCode is invalid.',
    },
    RECIPE_PRODUCESSTOCKITEM_INVALID: {
      code: 'ERCPPRD400',
      message: 'Recipe producesStockItem is invalid.',
    },
    RECIPE_PRODUCESTOCKCODE_INVALID: {
      code: 'ERCPPSTK400',
      message: 'Recipe produceStockCode is invalid.',
    },
    RECIPE_RECIPEITEMLIST_INVALID: {
      code: 'ERCPLST400',
      message: 'Recipe recipeItemList is invalid.',
    },
    RECIPE_ISNONBATCHBASED_INVALID: {
      code: 'ERCPIBB400',
      message: 'Recipe isNonBatchBased is invalid.',
    },
  },
  // #region REPORTS
  REPORT_PROPERTIES_ERROR: {
    code: 'ERPR400',
    message: 'A report property is invalid.',
    REPORT_STARTDATE_INVALID: {
      code: 'ERPRSTR400',
      message: 'Report start date is invalid.',
    },
    REPORT_ENDDATE_INVALID: {
      code: 'ERPREND400',
      message: 'Recipe end date is invalid.',
    },
    REPORT_DATES_INVALID: {
      code: 'ERPREND400',
      message: 'Recipe start date needs to be smaller than the end date.',
    },
    ACTUAL_STARTING_STOCK_INVALID: {
      code: 'ERPASS400',
      message: 'Actual starting stock on snapshot is invalid.',
    },
    ACTUAL_CLOSING_STOCK_INVALID: {
      code: 'ERPACS400',
      message: 'Actual closing stock on snapshot is invalid.',
    },
    REPORT_GENERATION_FAILED: {
      code: 'ERPG500',
      message: 'Report failed to generate.',
    },
  },
  // #endregion
  // #region SESSIONS
  SESSIONS_CREATE_FAILED: {
    code: 'ESSS406',
    message: 'Failed to create session.',
  },
  SESSIONS_PROPERTIES_ERROR: {
    code: 'ESSS400',
    message: 'A sessions property is invalid.',
    SESSIONS_USERID_INVALID: {
      code: 'ESSSUID400',
      message: 'Sessions user id is invalid.',
    },
  },
  // #endregion
  // #region STOCK DELIVERIES
  STOCKDELIVERY_PROPERTIES_ERROR: {
    code: 'ESTD400',
    message: 'A stock delivery property is invalid.',
    STOCKDELIVERY_ORDERNUMBER_INVALID: {
      code: 'ESTDORD400',
      message: 'Stock delivery order number is invalid.',
    },
    STOCKDELIVERY_INVOICENUMBER_INVALID: {
      code: 'ESTDINV400',
      message: 'Stock delivery invoice number is invalid.',
    },
    STOCKDELIVERY_DATERECEIVED_INVALID: {
      code: 'ESTDDTR400',
      message: 'Stock delivery date received is invalid.',
    },
    STOCKDELIVERY_TOTAL_INVALID: {
      code: 'ESTDTTL400',
      message: 'Stock delivery total is invalid.',
    },
    STOCKDELIVERY_SUPPLIERID_INVALID: {
      code: 'ESTDSPP400',
      message: 'Stock delivery supplier id is invalid.',
    },
    STOCKDELIVERY_ID_INVALID: {
      code: 'ESTDID400',
      message: 'Stock delivery id is invalid.',
    },
    STOCKDELIVERY_STOCKITEMS_INVALID: {
      code: 'ESTDSTK400',
      message: 'Stock delivery stock items list is invalid.',
      STOCKDELIVERY_STOCK_ITEM_UNIT_TYPE_INVALID: {
        code: 'ESTDSTKUTI406',
        message: 'The unit type received for the stock item is invalid.',
      },
    },
    STOCKDELIVERY_BATCHES_INVALID: {
      code: 'ESTDBAT400',
      message: 'Stock delivery batch list is invalid.',
    },
  },
  STOCKDELIVERY_INVOICENUMBER_EXISTS: {
    code: 'ESTDINV403',
    message: 'A stock delivery with this invoice number exists - invoice numbers must be unique.',
  },
  STOCKDELIVERY_ORDERNUMBER_EXISTS: {
    code: 'ESTDORD403',
    message: 'A stock delivery with this order number exists - order numbers must be unique.',
  },
  STOCKDELIVERY_NOT_FOUND: {
    code: 'ESTD404',
    message: 'Stock delivery was not found.',
  },
  CREDIT_NOTE_ORDERNUMBER_EXISTS: {
    code: 'ESTCNORD403',
    message: 'A credit note with this order number exists - order numbers must be unique.',
  },
  // #endregion
  // #region SOURCE TYPES
  SOURCETYPE_NOT_FOUND: {
    code: 'ESRT404',
    message: 'Source type was not found.',
  },
  // #endregion
  // #region STOCK ITEMS
  STARTINGANDCLOSINGSTOCK_PROPERTIES_ERROR: {
    code: 'ESAC400',
    message: 'A stock item property is invalid.',
    THEORETICALSTARTINGSTOCK_INVALID: {
      code: 'ESACTSS400',
      message: 'Theoretical starting stock is invalid.',
    },
    THEORETICALCLOSINGSTOCK_INVALID: {
      code: 'ESACTCS400',
      message: 'Theoretical closing stock is invalid.',
    },
    DATEOFCAPTURE_INVALID: {
      code: 'ESACTCS400',
      message: 'Date of capture is invalid.',
    },
  },
  STARTINGANDCLOSINGSTOCK_NOT_FOUND: {
    code: 'ESAC404',
    message: 'Starting and closing stock was not found.',
  },
  FAILED_TO_GET_STOCK_SNAPSHOT: {
    code: 'ESTOCKSNP404',
    message: 'Failed to get stock snapshot',
  },

  FAILED_TO_GET_STARTING_STOCK_SNAPSHOT: {
    code: 'ESSTOCKSNP404',
    message: 'Failed to get starting stock snapshot for the provided start date',
  },

  FAILED_TO_GET_CLOSING_STOCK_SNAPSHOT: {
    code: 'ECSTOCKSNP404',
    message: 'Failed to get closing stock snapshot for the provided start date',
  },

  FAILED_TO_GET_CLOSING_STOCK_FOR_PREVIOUS_DAY: {
    code: 'ECSTOCKSNP404',
    message: `Failed to get closing stock snapshot for the previous day.
    Please ensure that the store was cashed up for the previous day or that s store setup has been done if operating for the first time.`,
  },

  NO_STARTING_AND_CLOSING_STOCK_EVER_RECORDED: {
    code: 'ESTCLSTOCK404',
    message: 'No starting and closing stock ever recorded in the database',
  },

  NEGATIVE_STARTING_STOCK: {
    code: 'ESTCLSTNEG406',
    message: 'Cannot update closing stock with negative values. Update Value: <<NEW_CLOSING>>  Stock Item: <<STOCK_ITEM>> ',
  },

  STOCKLEVEL_NOT_FOUND: {
    code: 'ESL404',
    message: 'Stock level was not found.',
  },
  // #region STOCK ITEMS
  STOCKITEM_PROPERTIES_ERROR: {
    code: 'ESTK400',
    message: 'A stock item property is invalid.',
    STOCKITEM_STOCKCODE_INVALID: {
      code: 'ESTKSTK400',
      message: 'Stock item stock code is invalid.',
    },
    STOCKITEM_DESCRIPTION_INVALID: {
      code: 'ESTKDSC400',
      message: 'Stock item description is invalid.',
    },
    STOCKITEM_QUANTITYAVAILABLE_INVALID: {
      code: 'ESTKQTY400',
      message: 'Stock item quantity available is invalid.',
    },
    STOCKITEM_WASTEPERCENTAGE_INVALID: {
      code: 'ESTSTKWST400',
      message: 'Stock item waste percentage is invalid.',
    },
    STOCKITEM_BATCHSIZE_INVALID: {
      code: 'ESTKBTC400',
      message: 'Stock item batch size is invalid.',
    },
    STOCKITEM_MANUFACTURED_INVALID: {
      code: 'ESTKSTK400',
      message: 'Stock item manufactured is invalid.',
    },
    STOCKITEM_CONTROLLABLE_INVALID: {
      code: 'ESTKCNT400',
      message: 'Stock item controllable is invalid.',
    },
    STOCKITEM_ISENABLED_INVALID: {
      code: 'ESTKENB400',
      message: 'Stock item isEnabled is invalid.',
    },
    STOCKITEM_CATEGORY_INVALID: {
      code: 'ESTKCTG400',
      message: 'Stock item category is invalid.',
    },
    STOCKITEM_UNITTYPE_INVALID: {
      code: 'ESTKUNT400',
      message: 'Stock item unit type is invalid.',
    },
    STOCKITEM_VATEXEMPT_INVALID: {
      code: 'ESTKVAT400',
      message: 'Stock item VAT exemption is invalid.',
    },
    STOCKITEM_PREFERREDUNITTYPE_INVALID: {
      code: 'ESTKPUT400',
      message: 'Stock item preferred unit type is invalid.',
    },
  },
  STOCKITEM_STOCKCODE_EXISTS: {
    code: 'ESTKSTK403',
    message: 'This stock code already exists - stock codes must be unique.',
  },
  STOCKITEM_STOCKCODE_NOT_FOUND: {
    code: 'ESTKSTK404',
    message: 'Stock item stock code not found.',
  },
  STOCKITEM_NOT_FOUND: {
    code: 'ESTK404',
    message: 'Stock item not found.',
  },
  // #endregion
  // #region STOCK PRODUCTIONS
  STOCKPRODUCTION_PROPERTIES_ERROR: {
    code: 'EPRD400',
    message: 'A stock production property is invalid.',
    STOCKPRODUCTION_RECIPE_INVALID: {
      code: 'EPRDREC400',
      message: 'Stock production recipe is invalid.',
    },
    STOCKPRODUCTION_STOCKCODE_INVALID: {
      code: 'EPRDSTK400',
      message: 'Stock production stock code is invalid.',
    },
    STOCKPRODUCTION_BATCHES_INVALID: {
      code: 'EPRDBAT400',
      message: 'Stock production batch list is invalid.',
    },
    STOCKPRODUCTION_UNITTYPE_INVALID: {
      code: 'EPRDUNT400',
      message: 'Stock production unit type is invalid.',
    },
    STOCKPRODUCTION_QUANTITY_INVALID: {
      code: 'EPRDQTY400',
      message: 'Stock production quantity is invalid.',
    },
    STOCKPRODUCTION_DIVIDENDS_INVALID: {
      code: 'EPRDDIV406',
      message: 'Stock production dividends is invalid.',
      STOCKPRODUCTION_DIVIDENDS_STOCKCODE_INVALID: {
        code: 'EPRDDIV406',
        message: 'Stock production dividend stock item stock code is invalid.',
      },
      STOCKPRODUCTION_DIVIDENDS_QUANTITY_INVALID: {
        code: 'EPRDDIV406',
        message: 'Stock production dividend quantity is invalid.',
      },
      STOCKPRODUCTION_DIVIDENDS_REQUEST_INVALID: {
        code: 'EPRDDIVR406',
        message: 'Stock production dividends request data is invalid.',
      },
      STOCKPRODUCTION_DIVIDENDS_STOCK_PRODUCTION_IDENTIFIER_INVALID: {
        code: 'EPRDDIVPID406',
        message: 'Stock production dividend stock production identifier is invalid.',
      },
    },
  },
  STOCKPRODUCTION_NOT_FOUND: {
    code: 'EPRD404',
    message: 'Stock production not found.',
  },
  STOCKPRODUCTION_NUMBER_OF_QUOTIENT_BATCHES_INVALID: {
    code: 'EPRDQTN500',
    message: 'Quotient batches for stock production dividends invalid - expect one only.',
  },
  STOCKPRODUCTION_DIVIDENDS_UNPROCESSED_FOR_STOCK_ITEM: {
    code: 'EPRDDIVUNP500',
    message: 'A batch has been found for this stock item, and another cannot be produced until the dividends have been processed.',
  },
  STOCKPRODUCTION_STOCK_ITEM_HAS_NOT_DIVIDENDS: {
    code: 'EPRDDIVNON500',
    message: 'This stock item has no dividends.',
  },
  // #region STOCK WASTES
  STOCKWASTE_PROPERTIES_ERROR: {
    code: 'EWST400',
    message: 'A stock waste property is invalid.',
    STOCKWASTE_QUANTITY_INVALID: {
      code: 'EWSTQTY400',
      message: 'Stock waste quantity is invalid.',
    },
    STOCKWASTE_STOCKCODE_INVALID: {
      code: 'EWSTSTK400',
      message: 'Stock waste stock code is invalid.',
    },
    STOCKWASTE_UNITTYPE_INVALID: {
      code: 'EWSTUNT400',
      message: 'Stock waste unit type is invalid.',
    },
  },
  STOCKWASTE_NOT_FOUND: {
    code: 'EWST404',
    message: 'Stock waste not found.',
  },
  // #endregion
  // #region STOCK TRANSFERS
  STOCKTRANSFER_PROPERTIES_ERROR: {
    code: 'ETRN400',
    message: 'A stock transfer property is invalid.',
    STOCKTRANSFER_DATE_INVALID: {
      code: 'ETRNDAT400',
      message: 'Stock transfer date is invalid.',
    },
    STOCKTRANSFER_QUANTITY_INVALID: {
      code: 'ETRNQTY400',
      message: 'Stock transfer quantity is invalid.',
    },
    STOCKTRANSFER_STOCKITEMCODE_INVALID: {
      code: 'ETRNSTK400',
      message: 'Stock transfer stock code is invalid.',
    },
    STOCKTRANSFER_UNIT_TYPE_ID_INVALID: {
      code: 'ETRNUTI400',
      message: 'Stock transfer unit type is invalid.',
    },
    STOCKTRANSFER_STOCKTRANSFERRECIPIENT_INVALID: {
      code: 'ETRNREC400',
      message: 'Stock transfer stock transfer recipient is invalid.',
    },
    STOCKTRANSFER_UNITTYPE_INVALID: {
      code: 'ETRNUNT400',
      message: 'Stock transfer unit type is invalid.',
    },
  },
  STOCKTRANSFER_NOT_FOUND: {
    code: 'ETRN404',
    message: 'Stock transfer not found.',
  },
  STOCKTRANSFERRECIPIENT_PROPERTIES_ERROR: {
    code: 'EREC400',
    message: 'A stock transfer property is invalid.',
    STOCKTRANSFERRECIPIENT_NAME_INVALID: {
      code: 'ERECDAT400',
      message: 'Stock transfer recipient name is invalid.',
    },
    STOCKTRANSFERRECIPIENT_STOREID_INVALID: {
      code: 'ERECQTY400',
      message: 'Stock transfer recipient store id is invalid.',
    },
  },
  STOCKTRANSFERRECIPIENT_NOT_FOUND: {
    code: 'EREC404',
    message: 'Stock transfer recipient not found.',
  },
  // #endregion
  // #region STOCK ITEMS
  STOCKTAKE_PROPERTIES_ERROR: {
    code: 'ESTT400',
    message: 'A stock take property is invalid.',
    STOCKTAKE_ID_INVALID: {
      code: 'ESTTID400',
      message: 'Stock take id is invalid.',
    },
    STOCKTAKE_STOCKITEM_ID_INVALID: {
      code: 'ESTTITI400',
      message: 'Stock take stock item id is invalid.',
    },
    STOCKTAKE_DATE_INVALID: {
      code: 'ESTTDAT400',
      message: 'Stock take date is invalid.',
    },
    STOCKTAKE_STOCKITEMSTOCKCODE_INVALID: {
      code: 'ESTTSTC400',
      message: 'Stock take stock code is invalid.',
    },
    STOCKTAKE_QUANTITY_INVALID: {
      code: 'ESTTQTY400',
      message: 'Stock take quantity is invalid.',
    },
    STOCKTAKE_TOTAL_INVALID: {
      code: 'ESTTTTL400',
      message: 'Stock take total is invalid.',
    },
    STOCKTAKE_CONTROLLABLE_INVALID: {
      code: 'ESTTCNT400',
      message: 'Stock take controllable property is invalid.',
    },
    STOCKTAKE_STOCKTAKEAPPLIED_INVALID: {
      code: 'ESTTSTT400',
      message: 'Stock take stock take applied property is invalid.',
    },
    STOCKTAKE_UNITTYPE_INVALID: {
      code: 'ESTTUNT400',
      message: 'Stock take unit type is invalid.',
    },
    STOCKTAKE_STOCKITEMS_INVALID: {
      code: 'ESTTSTK400',
      message: 'Stock take stock items list is invalid.',
    },
    STOCKTAKE_STOCKTAKESTATE_INVALID: {
      code: 'ESTTSTS400',
      message: 'Stock take state property is invalid.',
    },
    STOCKTAKE_IS_STORE_SETUP_INVALID: {
      code: 'ESTTISS400',
      message: 'Stock take isStoreSetup property is invalid.',
    },
    STOCKTAKE_PROCESSING_VIA_SNAPSHOT_INVALID: {
      code: 'ESTTSNP500',
      message: 'While processing stock take stock items in accordance with a full stock take snapshot, a stock item was not found, when one was expected.',
    },
  },
  STOCKTAKE_NOT_FOUND: {
    code: 'ESTT404',
    message: 'Stock take not found.',
  },
  STOCKTAKE_FOR_STORESETUP_ALREADY_EXISTS: {
    code: 'ESTTSTE404',
    message: 'Stock take for store setup already exists.',
  },
  STOCKTAKE_ALREADY_EXISTS: {
    code: 'ESTE404',
    message: 'A stock take already exists for the provided date.',
  },
  STOCKTAKE_COMPLETE: {
    code: 'ESTT403',
    message: 'Stock take was already completed.',
    SNAPSHOT_GENERATION_INVALID: {
      code: 'ESTTSNP500',
      message: 'Generating the snapshot of stock items based on the stock take yielded an invalid result.',
    },
    STOCKTAKE_RESPONSE_INVALID: {
      code: 'ESTT500',
      message: 'Stock take complete - response invalid. Aborting.',
    },
  },
  STOCKTAKE_COMPLETE_INVALID: {
    code: 'ESTT403',
    message: 'Stock take is not in a valid state for completion.',
  },
  STOCKTAKESTATE_NOT_FOUND: {
    code: 'ESTS404',
    message: 'Stock take state not found.',
  },
  STOCKTAKE_UPDATE_INVALID: {
    code: 'ESTT410',
    message: 'Stock take update failed. Kindly retry again.',
  },
  STOCKTAKESTOCKITEM_PROPERTIES_ERROR: {
    code: 'ESKI400',
    message: 'A stock take stock item property is invalid.',
    STOCKTAKESTOCKITEM_STOCKITEMSTOCKCODE_INVALID: {
      code: 'ESKISTK400',
      message: 'Stock take stock item stock code is invalid.',
    },
    STOCKTAKESTOCKITEM_AVAILABLEQUANTITY_INVALID: {
      code: 'ESKIQTY400',
      message: 'Stock take stock item quantity available is invalid.',
    },
    STOCKTAKESTOCKITEM_BULKQUANTITY_INVALID: {
      code: 'ESKIBLK400',
      message: 'Stock take stock item bulk quantity is invalid.',
    },
    STOCKTAKESTOCKITEM_BULKQUANTITY_UNITTYPE_INVALID: {
      code: 'ESKIBLK400',
      message: 'Unit type for stock take stock item bulk quantity is invalid.',
    },
    STOCKTAKESTOCKITEM_PREPPEDQUANTITY_INVALID: {
      code: 'ESKIPRP400',
      message: 'Stock take stock item prepped quantity is invalid.',
    },
    STOCKTAKESTOCKITEM_PREPPEDQUANTITY_UNITTYPE_INVALID: {
      code: 'ESKIBLK400',
      message: 'Unit type for stock take stock item prepped quantity is invalid.',
    },
    STOCKTAKESTOCKITEM_QUANTITY_UNITTYPES_INVALID: {
      code: 'ESKIQTYUT400',
      message: 'Unit types for stock take stock item prepped and bulk quantities are not compatible - when converting to base, the base units do not match.',
    },
    STOCKTAKESTOCKITEM_STOCKTAKE_INVALID: {
      code: 'ESKISTT400',
      message: 'Stock take stock item stock take id is invalid.',
    },
    STOCKTAKESTOCKITEM_UNITTYPE_INVALID: {
      code: 'ESKISTT400',
      message: 'Stock take stock item unit type is invalid.',
    },
    STOCKTAKESTOCKITEM_WASTEPERCENTAGE_INVALID: {
      code: 'ESKIWSP400',
      message: 'Stock take stock item waste percentage is invalid.',
    },
    STOCKTAKESTOCKITEM_TOTALVALUE_INVALID: {
      code: 'ESKITLV400',
      message: 'Stock take stock item total value is invalid.',
    },
  },
  STOCKTAKESTOCKITEM_NOT_FOUND: {
    code: 'ESKI404',
    message: 'Stock take stock item not found.',
  },
  STOCKTAKE_LOCKED: {
    code: 'ESTL406',
    message: 'This stock take has been locked. After the 3rd of each month the previous months stock takes will be locked.',
  },
  // #endregion
  // #region SUPPLIER
  SUPPLIER_PROPERTIES_ERROR: {
    code: 'ESPP400',
    message: 'A supplier property is invalid.',
    SUPPLIER_ID_INVALID: {
      code: 'ESPPIDX400',
      message: 'Supplier id is invalid.',
    },
    SUPPLIER_NAME_INVALID: {
      code: 'ESPPNMX400',
      message: 'Supplier name is invalid.',
    },
    SUPPLIER_DESCRIPTION_INVALID: {
      code: 'ESPPDSC400',
      message: 'Supplier description is invalid.',
    },
    SUPPLIER_PHONE_INVALID: {
      code: 'ESPPPHN400',
      message: 'Supplier phone is invalid.',
    },
    SUPPLIER_EMAIL_INVALID: {
      code: 'ESPPEML400',
      message: 'Supplier email is invalid.',
    },
    SUPPLIER_FAX_INVALID: {
      code: 'ESPPFAX400',
      message: 'Supplier fax is invalid.',
    },
    SUPPLIER_ADDRESS1_INVALID: {
      code: 'ESPPAD1400',
      message: 'Supplier address1 invalid.',
    },
    SUPPLIER_ADDRESS2_INVALID: {
      code: 'ESPPAD2400',
      message: 'Supplier address2 is invalid.',
    },
    SUPPLIER_SUBURB_INVALID: {
      code: 'ESPPSBR400',
      message: 'Supplier suburb is invalid.',
    },
    SUPPLIER_CITY_INVALID: {
      code: 'ESPPCTY400',
      message: 'Supplier city is invalid.',
    },
    SUPPLIER_STATE_INVALID: {
      code: 'ESPPSTT400',
      message: 'Supplier state is invalid.',
    },
    SUPPLIER_POSTALCODE_INVALID: {
      code: 'ESPPPST400',
      message: 'Supplier postal code is invalid.',
    },
    SUPPLIER_ACCOUNTINGCODE_INVALID: {
      code: 'ESPPACC400',
      message: 'Supplier accounting code is invalid.',
    },
  },
  SUPPLIER_NOT_FOUND: {
    code: 'ESPP404',
    message: 'Supplier not found.',
  },
  // #endregion
  // #region TILL
  TILL_PROPERTIES_ERROR: {
    code: 'ETLL400',
    message: 'A till property is invalid.',
    TILL_ID_INVALID: {
      code: 'ETLLIDX400',
      message: 'Till id is invalid.',
    },
    TILL_APPID_INVALID: {
      code: 'ETLLAPP400',
      message: 'Till app id is invalid.',
    },
    TILL_KITCHENPRINTER_INVALID: {
      code: 'ESPPKTC400',
      message: 'Kitchen printer details are invalid.',
    },
    TILL_TILLPRINTER_INVALID: {
      code: 'ETLLTLLC400',
      message: 'Till printer details are invalid.',
    },
    TILL_KITCHENPRINTERTYPE_INVALID: {
      code: 'ESPPKTP400',
      message: 'Kitchen printer type is invalid.',
    },
    TILL_TILLPRINTERTYPE_INVALID: {
      code: 'ETLLTLTP400',
      message: 'Till printer type is invalid.',
    },
    TILL_KITCHENPRINTERTYPE_NOT_FOUND: {
      code: 'ESPPKTP404',
      message: 'Kitchen printer type not found.',
    },
    TILL_TILLPRINTERTYPE_NOT_FOUND: {
      code: 'ETLLTLTP404',
      message: 'Till printer type not found.',
    },
    TILL_ACTIVE_INVALID: {
      code: 'ETLLACT400',
      message: 'Till active state is invalid.',
    },
    TILL_OPENCASHDRAWER_INVALID: {
      code: 'ETLLOPCP400',
      message: 'Till setting to open cash drawer is invalid.',
    },
    TILL_FINGERPRINT_INVALID: {
      code: 'ETLLOPCP400',
      message: 'Till setting to enable fingerprint is invalid.',
    },
    TILL_UNIQUECODE_INVALID: {
      code: 'ETLLOPCP400',
      message: 'Till setting to enable uniquecode is invalid.',
    },
  },
  TILL_NOT_FOUND: {
    code: 'ETLL404',
    message: 'Till not found.',
  },
  SHIFT_NOT_FOUND: {
    code: 'ESHFTNF404',
    message: 'Shift not found',
  },
  // #endregion
  UNIDENTIFIED_ERROR: {
    code: 'E500',
    message: 'An unidentified error occurred.',
  },
  // #region FINGERPRINT
  FINGERPRINT_PROPERTIES_ERROR: {
    code: 'EFGP400',
    message: 'A fingerprint property is invalid.',
    FINGERPRINT_ID_INVALID: {
      code: 'EUSRID400',
      message: 'User id is invalid.',
    },
    FINGERPRINT_PRINT_INVALID: {
      code: 'EFGPPRT400',
      message: 'Fingerprint is invalid.',
    },
    FINGERPRINT_DESCRIPTION_INVALID: {
      code: 'EFGPDCP400',
      message: 'Fingerprint description is invalid.',
    },
    FINGERPRINT_USER_ID_INVALID: {
      code: 'EFGPUSR400',
      message: 'Fingerprint user id is invalid.',
    },
  },
  FINGERPRINT_NOT_FOUND: {
    code: 'EFGP404',
    message: 'Fingerprint not found.',
  },
  FINGERPRINT_ALREADY_EXISTS: {
    code: 'EFGP406',
    message: 'Fingerprint already exists',
  },
  // #endregion
  // #region USER
  USER_AUTH_ERROR: {
    code: 'EU401',
    message: 'User authentication failed.',
  },
  USER_NOT_FOUND: {
    code: 'EUSR404',
    message: 'User not found.',
  },
  USER_ALREADY_EXISTS: {
    code: 'EUSR406',
    message: 'User already exists',
  },
  USER_CODE_EXISTS: {
    code: 'EUSRCOD406',
    message: 'User code is invalid',
  },
  USER_UNIQUE_CODE_EXISTS: {
    code: 'WEUSRCOD406',
    message: 'Unique code has already been used, please change your unique code.',
  },
  USER_CELLPHONE_EXISTS: {
    code: 'EUSRCOD407',
    message: 'User cellphone has already been used.',
  },
  USER_PROPERTIES_ERROR: {
    code: 'EUSR400',
    message: 'A user property is invalid.',
    USER_ID_INVALID: {
      code: 'EUSRID406',
      message: 'User id is invalid.',
    },
    USER_UUID_INVALID: {
      code: 'EUSRUUID406',
      message: 'User uuid is invalid.',
    },
    USER_EMAIL_INVALID: {
      code: 'EUSREML406',
      message: 'User email is invalid.',
    },
    USER_PASSWORD_INVALID: {
      code: 'EUSRPSS406',
      message: 'User password is invalid.',
    },
    USER_CODE_INVALID: {
      code: 'EUSRPSS406',
      message: 'User code is invalid.',
    },
    USER_FIRSTNAME_INVALID: {
      code: 'EUSRFRS406',
      message: 'User first name is invalid.',
    },
    USER_LASTNAME_INVALID: {
      code: 'EUSRLST406',
      message: 'User last name is invalid.',
    },
    USER_USERGROUP_INVALID: {
      code: 'EUSRUGR406',
      message: 'User user group is invalid.',
    },
    USER_PERMISSIONS_INVALID: {
      code: 'EUSRPRM406',
      message: 'User permissions are invalid.',
    },
  },
  USERGROUP_NOT_FOUND: {
    code: 'EUGR404',
    message: 'User group not found.',
  },
  // #region FINGERPRINT
  USERGROUP_PROPERTIES_ERROR: {
    code: 'EUGR400',
    message: 'A user group property is invalid.',
    USERGROUP_ID_INVALID: {
      code: 'EUGRID400',
      message: 'User id is invalid.',
    },
    USERGROUP_RATE_INVALID: {
      code: 'EUGRRTE400',
      message: 'User group rate is invalid.',
    },
    USERGROUP_OVERTIME_RATE_INVALID: {
      code: 'EUGRORT400',
      message: 'User group overtime rate is invalid.',
    },
    USERGROUP_NAME_INVALID: {
      code: 'EUGRNAM400',
      message: 'User group name is invalid.',
    },
  },
  // #endregion
  USER_HAS_OPEN_SHIFT: {
    code: 'EUDOS4-6',
    message: 'User has an open shift. Cannot delete a user with an open shift.',
  },
  MENU_DATA_NOT_FOUND: {
    code: 'EMD404',
    message: 'Menu data not found.',
  },
  // #endregion
  // #region GENERAL VALUE ERRORS
  ENTITY_NOT_FOUND: {
    code: 'EENT404',
    message: 'Entity not found.',
  },
  NULL_EXCEPTION: {
    code: 'EVAL406',
    message: 'Value is null or undefined.',
  },
  // #endregion
  INVALID_OPERATOR: {
    code: 'EOP406',
    message: 'Invalid operator',
  },

  INVALID_RULE_ROOT: {
    code: 'ERULRO406',
    message: "Rule root must be either 'all' or 'any'. Cannot have both.",
  },

  INVALID_RULE: {
    code: 'ERULE406',
    message: "Rule root must be either 'all' or 'any'",
  },

  INVALID_SPECIAL_RULE_ROOT: {
    code: 'ESPRUL406',
    message: "Rule root must be 'special'",
  },

  INVALID_PIZZA_BASE: {
    code: 'EPBASE406',
    message: 'Unknown Pizza Base',
  },

  INVALID_PIZZA_SIZE: {
    code: 'EPSIZE406',
    message: 'Invalid Pizza Size',
  },

  INVALID_MENU_ITEM_EXTRA: {
    code: 'EMIEX406',
    message: 'Invalid menu item extra',
  },

  INVALID_MENU_ITEM: {
    code: 'EMITM406',
    message: 'Invalid menu item',
  },

  INVALID_SPECIAL: {
    code: 'ESPCL406',
    message: 'Invalid special',
  },

  NO_SPECIALS_FOUND: {
    code: 'ESPCL404',
    message: 'No specials found',
  },

  INVALID_MENU_PROFILE: {
    code: 'EMPROF406',
    message: 'Invalid menu PROFILE',
  },

  INVALID_MENU_CATEGORY: {
    code: 'EMCAT406',
    message: 'Invalid menu category',
  },

  INVALID_PRICING_STRATEGY: {
    code: 'EPRICE406',
    message: 'Unknown pricing strategy ',
  },

  INVALID_STORE_UUID: {
    code: 'ESUUID406',
    message: 'Cannot Find Store In Database',
  },

  NO_OPEN_STORE_LOGS: {
    code: 'EOPSTR404',
    message: 'Store is closed for trading. Please open store to be able to cashup',
  },

  INVALID_CUSTOMER_ID: {
    code: 'ECUSTID406',
    message: 'Invalid Customer Id',
  },

  NO_OPEN_SHIFT: {
    code: 'ENOSHFT404',
    message: 'No Open Shift found for the provided Shift Number',
  },

  DUPLICATE_SHIFT_NUMBER: {
    code: 'ESHFT406',
    message: 'The generated shift number already exists in the database. Please assign again to generate a new shift number',
  },

  NO_OPEN_CASHIER_SHIFT: {
    code: 'ENOCASHSHFT404',
    message: 'No Open Shift found for the provided Cashier ID',
  },

  CASHIER_ALREADY_HAS_OPEN_SHIFT: {
    code: 'ECASHOPSHFT406',
    message: 'Cashier already has open shift',
  },

  INVALID_ORDER_TYPE: {
    code: 'EORDTYP406',
    message: ' Invalid Order Type',
  },

  INVALID_ORDER_QUERY_STATUS: {
    code: 'EORDQS406',
    message: ' Invalid Order Query Status',
  },

  INVALID_ORDER_ID: {
    code: 'EORDID406',
    message: ' Invalid Order ID',
  },

  ORDER_ID_NOT_FOUND: {
    code: 'EORDER404',
    message: 'Order not found',
  },

  ORDER_ALREADY_CANCELLED: {
    code: 'EORDCAN406',
    message: 'Order has already been cancelled',
  },

  NOT_AWAITING_PAYMENT: {
    code: 'EOAWTPAY406',
    message: 'Only orders in awaiting payment status can be paid',
  },

  ORDER_CANNOT_BE_CANCELLED: {
    code: 'EORDCAN406',
    message: 'Only succefull orders can be cancelled. The status of this order indicates it might have failed.',
  },

  ORDER_SNAPSHOT_NOT_FOUND: {
    code: 'EORDSNP404',
    message: 'Ordersnapshot not found',
  },
  INVALID_PAYMENT_TYPE: {
    code: 'EPAYT406',
    message: 'Invalid payment type',
  },

  INVALID_VOUCHER_TYPE: {
    code: 'EVOUCT406',
    message: 'Invalid voucher type',
  },

  INVALID_VOUCHER_DETAILS: {
    code: 'EVOUDT406',
    message: 'Invalid voucher details',
  },

  INVALID_DISCOUNT_CODE: {
    code: 'EDISCOD406',
    message: ' Invalid Discount code',
  },

  NO_DISCOUNTS_FOUND: {
    code: 'EDISC404',
    message: 'No active discounts found',
  },

  INVALID_APP_ID: {
    code: 'EAPPID406',
    message: ' Invalid App ID',
  },

  NO_CASHUPS_FOUND: {
    code: 'ENOCSHUP404',
    message: 'No cashup found. This may be because Till float was not set for the provided shift',
  },

  NO_CASHUPS_FOUND_FOR_TODAY: {
    code: 'CASHUP404',
    message: 'No Cash Ups found for today ',
  },

  NO_ORDERS_FOUND: {
    code: 'ENORDST404',
    message: 'No orders found',
  },

  NO_ORDER_FOUND: {
    code: 'ENORDER404',
    message: 'No order found',
  },

  NO_ORDERS_FOUND_FOR_SHIFT: {
    code: 'EORDSHFT404',
    message: 'No orders found for the provided shift number',
  },

  ERROR_CALCULATING_SHIFT_TOTALS: {
    code: 'ESHFTTOT406',
    message: 'Error calculating shift totals',
  },

  CASHUP_NOT_DONE: {
    code: 'ECASHUP406',
    message: 'Cashup for shift has not been done. Please cashup before closing this shift.',
  },

  CASHUP_NOT_FOUND: {
    code: 'ECASHUP404',
    message: 'Cashup not found.',
  },

  TILL_ALREADY_REGISTERED: {
    code: 'ETILL406',
    message: 'Till has already been registered',
  },

  STORE_CASHUP_NO_SHIFTS: {
    code: 'ESCNOS406',
    message: 'There are no shifts for the day.',
  },

  STORE_CASHUP_SHIFTS_OPENED: {
    code: 'ESCSFO406',
    message: 'There are still opened shifts. Please close them before cashing up the store.',
  },

  STORE_CASHUP_NOT_FOUND: {
    code: 'ESCSFO404',
    message: 'Store cashup not found.',
  },

  STORE_NOT_CASHEDUP_PREVIOUS_DAY: {
    code: 'ESNCPD406',
    message: 'Store was not cashed up for previous day. Please cash up the store using the app.',
  },

  STORE_NOT_CASHEDUP_FOR_ST: {
    code: 'ESNCST406',
    message: 'Store has not been cashed up. Please cash up the store using the app and try again.',
  },

  SPECIFIC_MENU_ITEM_NOT_FOUND: {
    code: 'SPECMI404',
    message: 'Specific menu item not found',
  },

  SPECIFIC_MENU_ITEM_RECIPE_NOT_FOUND: {
    code: 'SPECMIR404',
    message: 'Specific menu item recipe not found',
  },

  SPECIAL_STOCK_ITEM_NOT_FOUND: {
    code: 'SPECSTCK404',
    message: 'Special stock item not found',
  },

  // #region STOCK TRANSACTIONS
  STOCK_TRANSACTION_NOT_FOUND: {
    code: 'ETRN404',
    message: 'Stock transaction not found.',
  },
  STOCK_TRANSACTION_CAPTURE_FAILED: {
    code: 'ETRNCAP406',
    message: 'Failed to capture stock transaction.',
  },
  TRANSACTION_PROPERTIES_ERROR: {
    code: 'ETRNP400',
    message: 'Stock transaction property is invalid.',
    TRANSACTION_ID_INVALID: {
      code: 'ETRNPID400',
      message: 'Stock transaction id is invalid.',
    },
    TRANSACTION_STOCK_ITEM_STOCK_CODE_ID_INVALID: {
      code: 'ETRNPSTK400',
      message: 'Stock transaction stock item stock code is invalid.',
    },
    TRANSACTION_SOURCE_ID_INVALID: {
      code: 'ETRNPSRCID400',
      message: 'Stock transaction source id is invalid.',
    },
    TRANSACTION_SOURCE_TYPE_INVALID: {
      code: 'ETRNPSRCTYP400',
      message: 'Stock transaction source type is invalid.',
    },
    TRANSACTION_TRANSACTION_COST_INVALID: {
      code: 'ETRNPTRNCST400',
      message: 'Stock transaction transaction cost is invalid.',
    },
    TRANSACTION_QUANTITY_INVALID: {
      code: 'ETRNPQTY400',
      message: 'Stock transaction quantity is invalid.',
    },
    TRANSACTION_BATCH_ID_INVALID: {
      code: 'ETRNPBTCID400',
      message: 'Stock transaction batch id is invalid.',
    },
    TRANSACTION_UNIT_TYPE_ID_INVALID: {
      code: 'ETRNPUNTID400',
      message: 'Stock transaction unit type id is invalid.',
    },
    TRANSACTION_USER_ID_INVALID: {
      code: 'ETRNPUSRID400',
      message: 'Stock transaction user id is invalid.',
    },
  },
  // #endregion

  GENERIC_RECIPE_NOT_FOUND: {
    code: 'EGREC404',
    message: 'Generic recipe was not found for this item.',
  },
  CONVERSION_ERROR: {
    code: 'ECON500',
    message: 'An error occurred while executing a conversion.',
    CONVERSION_ERROR_CURRENT_QUANTITY_INVALID: {
      code: 'ECONCQ500',
      message: 'The current quantity intended for conversion is invalid.',
    },
    CONVERSION_ERROR_TARGET_UNIT_TYPE_INVALID: {
      code: 'ECONTU500',
      message: 'The target unit type for conversion is invalid.',
    },
    CONVERSION_CROSS_CONVERSION_NOT_SUPPORTED: {
      code: 'ECONCC500',
      message: 'Cross-conversions are not supported - this caused the conversion to fail.',
    },
    CONVERSION_CONVERSION_FOR_TARGET_INVALID: {
      code: 'ECONTC500',
      message: 'Conversion data for target unit type is invalid.',
    },
  },
  PRINTING: {
    code: 'EPRNT406',
    message: 'A printing error occured',
    INVALID_RECIEPT_TYPE: {
      code: 'EPRNTRT406',
      message: 'Invalid receipt type',
    },
    FAILED_TO_CONNECT: {
      code: 'EPRNTCON406',
      message: 'Failed to connect to printer',
    },
    UNKNOWN_PRINTER_TYPE: {
      code: 'EPRNTYPE406',
      message: 'Unknown Printer Type',
    },
  },
  // #region VOUCHERS
  VOUCHERS: {
    code: 'ECON500',
    message: 'An error occurred while processing the vouchers.',
    VOUCHERS_LOW_BALANCE: {
      code: 'EVOULB406',
      message: 'The voucher balance is not enough to cover the whole amount.',
    },
  },
  // #endregion

  SCHEDULES_NOT_FOUND: {
    code: 'SCHSNFND405',
    message: 'Schedules was not found',
  },
  SCHEDULE_NOT_FOUND: {
    code: 'SCHNFND405',
    message: 'Schedule was not found',
  },
  SCHEDULE_CREATE_ERROR: {
    code: 'SCHNEW405',
    message: 'Failed to create schedule',
  },
  SCHEDULE_UPDATE_ERROR: {
    code: 'SCHUP405',
    message: 'Failed to update schedule',
  },
  SCHEDULE_DELETE_ERROR: {
    code: 'SCHDEL405',
    message: 'Failed to delete schedule',
  },

  USER_ACTIVITY_AUDIT_ERROR: {
    code: 'EUAA100',
    message: 'A user audit property is invalid.',

    EMPLOYEE_ID_INVALID: {
      code: 'EUAAEMPID401',
      message: 'Employee id is invalid.',
    },
    EMPLOYEE_NAME_INVALID: {
      code: 'EUAAEMPNAM402',
      message: 'Employee Name is invalid.',
    },
    ACTIVITY_CODE_INVALID: {
      code: 'EUAAACTCD403',
      message: 'User Activity Code is invalid.',
    },
    ACTIVITY_DESC_INVALID: {
      code: 'EUAAACTDES404',
      message: 'User Activity Description is invalid.',
    },
    COUNTER_ID_INVALID: {
      code: 'EUAACOUID405',
      message: 'Counter id is invalid.',
    },
    COUNTER_DESC_INVALID: {
      code: 'EUAACOUDES406',
      message: 'Counter Description is invalid.',
    },
    USER_USERGROUP_INVALID: {
      code: 'EUSRUGR406',
      message: 'User user group is invalid.',
    },
    ADDITIONAL_INFO: {
      code: 'EUAAACTDES405',
      message: 'Additional Information is invalid.',
    },
  },
  // #region UBEREATS
  UBER_EATS: {
    code: 'UE500',
    message: 'An error occurred while processing order from Uber Eats.',
    OAUTH_FAILED: {
      code: 'UEOA500',
      message: 'Failed to acquire oauth access token.',
    },
    FETCH_ORDER_FAILED: {
      code: 'UEFO500',
      message: 'Failed to fetch order.',
    },
    ACCEPT_ORDER_FAILED: {
      code: 'UEAO500',
      message: 'Failed to accept pos order.',
    },
    DENY_ORDER_FAILED: {
      code: 'UEDO500',
      message: 'Failed to deny pos order.',
    },
  },
  FAILED_REPORT: {
    code: 'RPTGEN406',
    message: 'There was an error generating this report. \nPlease contact technical support on \n087 055 0777',
  },
  CASHUP_FAILED_REPORT: {
    code: 'RPTGEN407',
    message: 'No cashup found for this date. \nPlease open RP POS application and submit your store cashup for this date in order for the cashup report to be available.',
  },
  NO_DATA_REPORT: {
    code: 'RPTNODATA406',
    message: 'No data found for the provided date range',
  },
  STORELOGS: {
    code: 'SL500',
    message: 'An error occurred while processing your store logs',
    STORE_CLOSED: {
      code: 'SLSC500',
      message: 'The store is closed.',
    },
  },
  // #endregion
  OUTSTANDING_ORDER_FOUND: {
    code: 'EUSR404',
    message: 'THERE ARE OUTSTANDING ORDERS LEFT.',
  },

  REQUEST_HEADER_MISSING: {
    code: 400,
    message: 'auth token is missing.',
  },
  JWT_INCORRECT_TOKEN: {
    code: 401,
    message: 'incorrect token.',
  },
  JWT_REFRESH_TOKEN_MISSING: {
    code: 400,
    message: 'refresh token is missing.',
  },
  JWT_REFRESH_TOKEN_EXPIRED: {
    code: 401,
    message: 'refresh token is expired.',
  },

  // #region Modifiers error
  MODIFIER_PROPERTIES_ERROR: {
    code: 'EMOD400',
    message: 'A modifier item property is invalid.',
    MODIFIER_MODIFIERCODE_INVALID: {
      code: 'EMODCODE400',
      message: 'Modifiers item modifier code is invalid.',
    },
    MODIFIER_STOCKCODE_INVALID: {
      code: 'EMODSCODE400',
      message: 'Modifiers item stock code is invalid.',
    },
    
    MODIFIER_NAME_INVALID: {
      code: 'EMODNAME400',
      message: 'Modifier item name is invalid.',
    },
    MODIFIER_AMOUNT_INVALID: {
      code: 'EMODAMT400',
      message: 'Modifier item amount is invalid.',
    },
    MODIFIER_EXTRAAMOUNT_INVALID: {
      code: 'EMODEAMT400',
      message: 'Modifier item extra amount is invalid.',
    },

    MODIFIER_ISREPEAT_INVALID: {
      code: 'EMODISREP400',
      message: 'Modifier item  isRepeatable  is invalid.',
    },
    MODIFIER_ISUNLIMIT_INVALID: {
      code: 'EMODUNLIM400',
      message: 'Modifier item  isUnlimited  is invalid.',
    },
    MODIFIER_MAXLIMIT_INVALID: {
      code: 'EMODMAXLIMIT400',
      message: 'Modifier item  maxlimitvalue is invalid.',
    },
    STOCKITEM_ISACTIVE_INVALID: {
      code: 'EMODISACT400',
      message: 'Modifier item isActive is invalid.',
    },

  },
  MODIFIERS_CODE_EXISTS: {
    code: 'WMODCOD406',
    message: 'Modifier code has already been used, please change your Modifier code.',
  },

  // #endregion
  // #region Login User
  USER_NOT_FOUND: {
    code: 'EUSR404',
    message: 'User not found.',
  },
  USER_AUTH_ERROR: {
    code: 'EU401',
    message: 'User authentication failed.',
  },
  UNIDENTIFIED_ERROR: {
    code: 'E500',
    message: 'An unidentified error occurred.',
  },
  USER_PROPERTIES_ERROR: {
    code: 'EUSR400',
    message: 'A user property is invalid.',
    USER_ID_INVALID: {
      code: 'EUSRID406',
      message: 'User id is invalid.',
    },
    USER_UUID_INVALID: {
      code: 'EUSRUUID406',
      message: 'User uuid is invalid.',
    },
    USER_EMAIL_INVALID: {
      code: 'EUSREML406',
      message: 'User email is invalid.',
    },
    USER_PASSWORD_INVALID: {
      code: 'EUSRPSS406',
      message: 'User password is invalid.',
    },
    USER_CODE_INVALID: {
      code: 'EUSRPSS406',
      message: 'User code is invalid.',
    },
    USER_FIRSTNAME_INVALID: {
      code: 'EUSRFRS406',
      message: 'User first name is invalid.',
    },
    USER_LASTNAME_INVALID: {
      code: 'EUSRLST406',
      message: 'User last name is invalid.',
    },
    USER_USERGROUP_INVALID: {
      code: 'EUSRUGR406',
      message: 'User user group is invalid.',
    },
    USER_PERMISSIONS_INVALID: {
      code: 'EUSRPRM406',
      message: 'User permissions are invalid.',
    },
  },
  // #endregion
};

export default errors;
