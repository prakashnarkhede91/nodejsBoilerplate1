export const responseMessages = {
  REQUEST_SENT: {
    message: 'A request has been sent to Serve Software Support and your will be attended to shortly.',
  },
};
