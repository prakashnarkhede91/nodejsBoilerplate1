
const {
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
  verifyAccessToken,
} = require('./');

module.exports = async (req, res, next) => {
  console.log('🚀 ^~^ - module.exports= - req', req, next);
  try {
    // check for auth header from client
    const header = req.headers.authorization;

    if (!header) {
      next({ status: 403, message: 'auth header is missing' });
      return;
    }
    const userId = verifyAccessToken(header, next);

    if (!userId) {
      next({ status: 403, message: 'incorrect token' });
      return;
    }

    next();
  } catch (err) {
    next(err);
  }
};