import { ErrorResponse } from '../../utils/responses';
import statusCodes from '../statuses/statusCodes';
import { errors } from '../errors';




const JWT = require('jsonwebtoken');

module.exports = {
  signAccessToken: (userId) => {
    return new Promise((resolve, reject) => {
      const payload = { userId };
      const secret = process.env.ACCESS_TOKEN_SECRET;
      const options = {
        expiresIn: '1d',
        issuer: 'bnry.com',
        audience: 'userId',
      };
      JWT.sign(payload, secret, options, (err, token) => {
        if (err) {
          console.log(err.message);
          return;
        }
        resolve(token);
      });
    });
  },
  verifyAccessToken: (ctx, next) => {
    if (!ctx.request.header['x-access-token']) {
      const exception = { errorCode: statusCodes.NOT_AUTHORIZED, errorMessage: errors.REQUEST_HEADER_MISSING.message };
      const response = new ErrorResponse(exception, [], statusCodes.NOT_AUTHORIZED);
      ctx.status = response.status;
      ctx.body = response;
      return;
    }
    const token = ctx.request.header['x-access-token'];
    JWT.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, payload) => {
      if (err) {
        const exception = { errorCode: statusCodes.NOT_AUTHORIZED, errorMessage: errors.JWT_INCORRECT_TOKEN.message };
        const response = new ErrorResponse(exception, [], statusCodes.NOT_AUTHORIZED);
        ctx.status = response.status;
        ctx.body = response;
        return;
      }
      ctx.req.payload = payload;
      next(ctx);
    });
  },
  signRefreshToken: (userId) => {
    return new Promise((resolve, reject) => {
      const payload = { userId };
      const secret = process.env.REFRESH_TOKEN_SECRET;
      const options = {
        expiresIn: '365d',
        issuer: 'bnry.com',
        audience: 'userId',
      };
      JWT.sign(payload, secret, options, (err, token) => {
        if (err) {
          console.log(err.message);
          // reject(err)
          reject(new ErrorResponse(err.message));
        }
        resolve(token);
      });
    });
  },
  verifyRefreshToken: (ctx, refreshToken) => {
    return new Promise((resolve, reject) => {
      JWT.verify(
        refreshToken,
        process.env.REFRESH_TOKEN_SECRET,
        (err, payload) => {
          if (err) {
            return resolve(null);
          }
          const { userId } = payload;
          return resolve(userId);
        },
      );
    });
  },
};

