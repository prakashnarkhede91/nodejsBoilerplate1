import Koa from 'koa';
import koaBody from 'koa-bodyparser';
import cors from 'koa-cors';
import helmet from 'koa-helmet';
import mount from 'koa-mount';
import { swaggerDoc, apiSpec } from 'swagger-json';
import config from './../config';
import users from '../routes/users';
import auth from '../routes/auth';
import modifires from '../routes/modifires';



const { basePath, port, bindAddress, sessionSecret } = config.webServer;
const swStats = require('swagger-stats');
const e2k = require('express-to-koa');
const { ui, validate } = require('swagger2-koa');
const swagger = require('swagger2');

const swaggerDocument = swagger.loadDocumentSync('swagger.json');

const app = new Koa();

const options = {
  origin: true,
  credentials: true,
  allowHeaders: 'origin, content-type, accept, authorization',
  allowMethods: 'GET, POST, PUT, DELETE, OPTIONS, HEAD',
};

const limit = '10mb';
app.use(e2k(swStats.getMiddleware({ swaggerSpec: swaggerDoc })));
const api = {
  async initApi() {
    app.proxy = true;
    app.keys = [sessionSecret];
    app
      .use(cors(options))
      .use(helmet())
      .use(koaBody({ formLimit: limit, jsonLimit: limit, textLimit: limit }))
      .use(ui(swaggerDocument, '/swagger'))
      .use(mount(`/${basePath}/users`, users))
      .use(mount(`/${basePath}/auth`, auth))
      .use(mount(`/${basePath}/modifires`, modifires))
      .listen(port, bindAddress);
  },
};

export default api;
