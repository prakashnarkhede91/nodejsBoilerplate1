import { ErrorResponse, SuccessResponse } from '../../utils/responses';
import { errorHandlers, errors } from '../../utils/errors';
import shiftActions from '../../transactional/shift/shiftActions';
import database from '../../data/database';
import { decrypt } from '../../utils/crypto/decrypt';
import callActions from '../../transactional/call/callActions';

const SHIFTS = 'Shifts';
const CASHUPS = 'CashUps';

export const endShift = async ({ shiftNumber }) => {
  const transaction = await database.sequelize.transaction();
  try {
    const shiftNo = decrypt(shiftNumber);
    const shiftResponse = await shiftActions.getShiftByShiftNumber(shiftNo);
    if (!shiftResponse.success || shiftResponse.data.shiftClosed) {
      errorHandlers.throwException(
        'endShift',
        errors.NO_OPEN_SHIFT,
        null,
        `Identifier: ${JSON.stringify(shiftNumber)}`,
      );
    }
    const shift = shiftResponse.data;
    const updatedShift = {
      shiftEnd: new Date(),
      shiftClosed: true,
    };

    const updatedShiftResponse = await shiftActions.updateShift(
      shift.id,
      updatedShift,
      transaction,
    );

    if (!updatedShiftResponse.success) {
      errorHandlers.throwException('endShift', updatedShiftResponse, null);
    }

    const updatedStatus = {
      status: true,
    };

    const updatedCallResponse = await callActions.closeAgentCall(
      shift.User.extension,
      updatedStatus,
      transaction,
    );

    await transaction.commit();

    return new SuccessResponse(shiftNumber);
  } catch (exception) {
    await transaction.rollback();
    // eslint-disable-next-line
    console.debug(exception);
    return new ErrorResponse(exception);
  }
};
