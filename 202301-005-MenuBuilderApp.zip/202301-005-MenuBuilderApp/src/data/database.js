import Sequelize from 'sequelize';

import Customers from './models/customer/customer';
import permissions from './models/users/permissions';
import userGroups from './models/users/userGroups';
import userPermissions from './models/users/userPermissions';
import users from './models/users/user';

import CustomerUsersMapping from './models/customer/customerUsersMapping';
import config from './dbConfig';

const {
  host,
  port,
  database,
  username,
  password,
  dialect,
  sequelizeLogsEnabled,
} = config;

const sequelize = new Sequelize(database, username, password, {
  host,
  port,
  dialect,
  operatorsAliases: false,
  timezone: '+02:00',
  // FIXME:
  dialectOptions: {
    // for reading data from db and appyling the correct time zone
    typeCast(field, next) {
      if (
        field.type === 'DATETIME' ||
        field.type === 'TIMESTAMP' ||
        field.type === 'DATE' ||
        field.type === 'TIME'
      ) {
        return new Date(`${field.string()}Z`);
      }
      return next();
    },
    connectTimeout: 240000,
    charset: 'latin1',
    collate: 'latin1_swedish_ci',
    multipleStatements: true,
    ssl: {
      require: true,
      rejectUnauthorized: false,
    },
  },
  pool: {
    max: 30,
    min: 0,
    idle: 10000,
    acquire: 240000,
  },
  logging: sequelizeLogsEnabled, // disable sequelize query logging
});

const db = {
  sequelize,
  Sequelize,
};

// #region USERS AND PERMISSIONS
db.Customers = sequelize.import('Customers', Customers);
db.UserPermissions = sequelize.import('userPermissions', userPermissions);
db.UserGroups = sequelize.import('userGroups', userGroups);
db.Permissions = sequelize.import('permissions', permissions);
db.Users = sequelize.import('users', users);
db.CustomerUsersMapping = sequelize.import('CustomerUsersMapping', CustomerUsersMapping);
// #end user activity audit

Object.keys(db).forEach((modelName) => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

export default db;
