import { isEmpty } from 'lodash';
import Sequelize from 'sequelize';
import { paginate } from '../../../utils/misc/pagination';

export default (sequelize, DataTypes) => {
  const Users = sequelize.define(
    'Users',
    {
      uuid: {
        type: DataTypes.UUID,
        allowNull: false,
        unique: true,
        defaultValue: Sequelize.UUIDV4,
      },
      firstName: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      lastName: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
      },
      cellphone: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      dateOfBirth: {
        type: DataTypes.DATEONLY,
        allowNull: true,
      },
      userName: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
      },
      password: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      order: { type: DataTypes.INTEGER, allowNull: false,unique: true },
      isActive: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      isDeleted: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
      },
    },
    {
      schema: 'serveup',
      // If don't want createdAt
      createdAt: false,
      // If don't want updatedAt
      updatedAt: false,
      // If don't want deletedAt
      deletedAt: false,
      paranoid: false,
      hooks: {},
    },
  );

  Users.associate = (models) => {
    Users.belongsTo(models.UserGroups, {
      targetKey: 'userGroupCode',
      foreignKey: {
        name: 'userGroupCode',
        allowNull: false,
      },
    });
    Users.belongsTo(models.Customers, {
      targetKey: 'uuid',
      foreignKey: {
        name: 'customerUuid',
        allowNull: false,
      },
    });
    Users.hasMany(models.CustomerUsersMapping, {
      foreignKey: {
        name: 'userId',
      },
    });
  };




  Users.getAll = async () => {
    return Users.findAll({
      // where: {
      //   groupId: 9,
      // },
    });
  };

  Users.getAllByPaginated = async (identifiers, queryParams) => {
    // const sqlQuery = {
    //   where: identifiers,
    //   attributes: { exclude: ['password', 'code'] },
    // };

    // if (!isEmpty(queryParams)) {
    //   const { limit, offset } = paginate(queryParams);
    //   sqlQuery.limit = limit;
    //   sqlQuery.offset = offset;
    // }

    return Users.findAll();// sqlQuery
  };

  Users.getOneByCode = async (code, includePassword) => {
    if (includePassword) {
      return Users.findOne({
        where: {
          isDeleted: false,
          code,
        },
        attributes: { include: ['password', 'code'] },
      });
    }
    return Users.findOne({
      where: {
        isDeleted: false,
        code,
      },
      attributes: { exclude: ['password', 'code'] },
    });
  };

  Users.getOneByEmail = async (email, includePassword) => {
    if (includePassword) {
      return Users.findOne({
        where: {
          isActive: true,
          email,
        },
        include: [
          {
            model: sequelize.models.CustomerUsersMapping,
            include: [
              {
                model: sequelize.models.UserGroups,
              },
              {
                model: sequelize.models.Customers,
              },
            ],
          },
        ],
        // attributes: { include: ['password'] },
      });
    }
    return Users.findOne({
      where: {
        isActive: true,
        email,
      },
      include: [
        {
          model: sequelize.models.UserGroups,
          // include: [
          //   {
          //     model: sequelize.models.UserPermissions,
          //     // attributes: ['permissionId'],
          //   },
          // ],
        },
        {
          model: sequelize.models.Customers,

        },
      ],
      attributes: { exclude: 'password' },
    });
  };

  Users.getOne = async (identifiers) => {
    return Users.findOne({
      where: identifiers,
      include: [
        {
          model: sequelize.models.UserGroups,
          include: [
            {
              model: sequelize.models.UserPermissions,
              attributes: ['permissionId'],
            },
          ],
        },
      ],
      attributes: { exclude: ['password', 'code'] },
    });
  };

  Users.updateExisting = async (identifier, input, transaction) => {
    return Users.update({ ...input, synced: false }, {
      where: {
        id: identifier,
      },
      transaction,
    });
  };

  Users.createNew = async (input, transaction) => {
    return Users.create({ ...input, synced: false }, {
      transaction,
    });
  };

  Users.doesExistUniqueCode = async (identifiers) => {
    const oneExists = await Users.findOne({
      where: { [Sequelize.Op.or]: identifiers, isDeleted: false },
    });
    if (oneExists != null && identifiers.code === oneExists.code) return true;
    else return false;
  };
  Users.doesExist = async (identifiers) => {
    const oneExists = await Users.findOne({
      where: { [Sequelize.Op.or]: identifiers, isDeleted: false },
    });
    // return valueValidators.hasValue(oneExists);
    return oneExists;
  };

  return Users;
};
