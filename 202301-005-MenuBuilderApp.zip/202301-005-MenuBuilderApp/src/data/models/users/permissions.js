export default (sequelize, DataTypes) => {
  const Permissions = sequelize.define(
    'Permissions', {
      permissionCode: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      description: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      isActive: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      isDeleted: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
      },
    },
    {
      schema: 'serveup',
      // If don't want createdAt
      createdAt: false,
      // If don't want updatedAt
      updatedAt: false,
      // If don't want deletedAt
      deletedAt: false,
      paranoid: false,
      hooks: {},
    },
  );
  Permissions.associate = (models) => {
    Permissions.belongsTo(models.Customers, {
      targetKey: 'uuid',
      foreignKey: {
        name: 'customerUuid',
        allowNull: false,
      },
    });
  };

  return Permissions;
};
