import Sequelize from 'sequelize';

import { valueValidators } from '../../../utils/validators';

export default (sequelize, DataTypes) => {
  const UserGroups = sequelize.define(
    'UserGroups', {
      userGroupCode: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      isActive: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      isDeleted: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
      },
    },
    {
      schema: 'serveup',
      // If don't want createdAt
      createdAt: false,
      // If don't want updatedAt
      updatedAt: false,
      // If don't want deletedAt
      deletedAt: false,
      paranoid: false,
      hooks: {},
    },
  );

  UserGroups.associate = (models) => {
    // UserGroups.hasMany(models.UserPermissions, {
    //   foreignKey: 'groupId',
    // });
    UserGroups.belongsTo(models.Customers, {
      targetKey: 'uuid',
      foreignKey: {
        name: 'customerUuid',
        allowNull: false,
      },
    });
  };

  UserGroups.getAll = async () => {
    return UserGroups.findAll({
      include: [
        {
          model: sequelize.models.UserPermissions,
          attributes: ['permissionId'],
        },
      ],
    });
  };

  return UserGroups;
};
