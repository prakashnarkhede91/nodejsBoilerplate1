import { isEmpty } from 'lodash';
import Sequelize from 'sequelize';
import { paginate } from '../../../utils/misc/pagination';

export default (sequelize, DataTypes) => {
  const CustomerUsersMapping = sequelize.define(
    'CustomerUsersMapping',
    {
      isDeleted: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
      },
    },
    {
      schema: 'serveup',
      // If don't want createdAt
      createdAt: false,
      // If don't want updatedAt
      updatedAt: false,
      // If don't want deletedAt
      deletedAt: false,
      paranoid: false,
      hooks: {},
    },
  );

  CustomerUsersMapping.associate = (models) => {
    CustomerUsersMapping.belongsTo(models.Customers, {
      targetKey: 'uuid',
      foreignKey: {
        name: 'customerUuid',
        allowNull: false,
      },
    });
    CustomerUsersMapping.belongsTo(models.Users, {
      foreignKey: {
        name: 'userId',
        allowNull: false,
      },
    });
    CustomerUsersMapping.belongsTo(models.UserGroups, {
      targetKey: 'userGroupCode',
      foreignKey: {
        name: 'userGroupCode',
        allowNull: false,
      },
    });
  };





  return CustomerUsersMapping;
};
