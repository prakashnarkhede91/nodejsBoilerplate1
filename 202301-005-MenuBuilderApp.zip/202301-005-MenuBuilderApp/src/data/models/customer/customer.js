import { isEmpty } from 'lodash';
import Sequelize from 'sequelize';
import { paginate } from '../../../utils/misc/pagination';

export default (sequelize, DataTypes) => {
  const Customers = sequelize.define(
    'Customers',
    {
      uuid: {
        type: DataTypes.UUID,
        allowNull: false,
        unique: true,
        defaultValue: Sequelize.UUIDV4,
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      description: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      isActive: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
      },
      isDeleted: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
      },
    },
    {
      schema: 'serveup',
      // If don't want createdAt
      createdAt: false,
      // If don't want updatedAt
      updatedAt: false,
      // If don't want deletedAt
      deletedAt: false,
      paranoid: false,
      hooks: {},
    },
  );

  // Customers.associate = (models) => {
  //   Customers.hasMany(models.UnitTypes, {
  //     as: 'customerUuid',
  //     foreignKey: 'uuid',
  //   });
  // };





  return Customers;
};
